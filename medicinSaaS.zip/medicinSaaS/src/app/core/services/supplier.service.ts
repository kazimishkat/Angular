import { Injectable, inject } from '@angular/core';
import { ApiService } from './api.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SupplierService {
  private api = inject(ApiService);

  getSuppliers(params: any = {}): Observable<any[]> {
    return this.api.get<any[]>('/suppliers', params);
  }

  getSupplierById(id: string): Observable<any> {
    return this.api.get<any>(`/suppliers/${id}`);
  }

  createSupplier(supplier: any): Observable<any> {
    return this.api.post<any>('/suppliers', supplier);
  }

  updateSupplier(id: string, supplier: any): Observable<any> {
    return this.api.put<any>(`/suppliers/${id}`, supplier);
  }

  getPurchaseOrders(params: any = {}): Observable<any[]> {
    return this.api.get<any[]>('/purchaseOrders', params);
  }

  createPurchaseOrder(order: any): Observable<any> {
    return this.api.post<any>('/purchaseOrders', order);
  }
}
