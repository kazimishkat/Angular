import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SalesService } from '../../../core/services/sales.service';
import { AuthService } from '../../../core/services/auth.service';
import { DataTableComponent, TableColumn } from '../../../shared/components/data-table/data-table';
import { SaleOrder } from '../../../core/models/order.model';

@Component({
  selector: 'app-my-orders',
  standalone: true,
  imports: [CommonModule, DataTableComponent],
  templateUrl: './my-orders.html',
  styles: []
})
export class MyOrdersComponent implements OnInit {
  private salesService = inject(SalesService);
  private authService = inject(AuthService);

  orders = signal<SaleOrder[]>([]);
  loading = signal(false);

  columns: TableColumn[] = [
    { key: 'orderNumber', label: 'Order #', sortable: true },
    { key: 'orderDate', label: 'Date', sortable: true },
    { key: 'totalAmount', label: 'Total Amount' },
    { key: 'status', label: 'Status' }
  ];

  ngOnInit() {
    this.loadOrders();
  }

  loadOrders() {
    const user = this.authService.currentUser();
    if (!user) return;

    this.loading.set(true);
    // In a real app, filter by customerId. For now, fetch all or mock filter.
    this.salesService.getSaleOrders().subscribe(data => {
      this.orders.set(data);
      this.loading.set(false);
    });
  }

  getStatusClass(status: string) {
    switch (status) {
      case 'Completed': return 'bg-success-subtle text-success';
      case 'Pending': return 'bg-warning-subtle text-warning';
      case 'Cancelled': return 'bg-danger-subtle text-danger';
      default: return 'bg-secondary-subtle text-secondary';
    }
  }
}
