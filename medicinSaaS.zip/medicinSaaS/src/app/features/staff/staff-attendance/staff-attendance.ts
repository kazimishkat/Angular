import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AttendanceService } from '../../../core/services/attendance.service';
import { AuthService } from '../../../core/services/auth.service';
import { AttendanceRecord } from '../../../core/models/user.model';
import { DataTableComponent, TableColumn } from '../../../shared/components/data-table/data-table';
import { ModalComponent } from '../../../shared/components/modal/modal';

@Component({
  selector: 'app-staff-attendance',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, DataTableComponent, ModalComponent],
  templateUrl: './staff-attendance.html'
})
export class StaffAttendanceComponent implements OnInit {
  private attendanceService = inject(AttendanceService);
  private authService = inject(AuthService);
  private fb = inject(FormBuilder);

  records = signal<AttendanceRecord[]>([]);
  loading = signal(false);
  todayRecord = signal<AttendanceRecord | null>(null);
  isManualModalOpen = signal(false);

  manualForm: FormGroup = this.fb.group({
    date: ['', Validators.required],
    entryTime: ['', Validators.required],
    outTime: ['']
  });

  columns: TableColumn[] = [
    { key: 'date', label: 'Date', sortable: true },
    { key: 'entryTime', label: 'Submitted Time' }
  ];

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    this.loading.set(true);
    const user = this.authService.currentUser();
    if (!user) return;

    this.attendanceService.getRecords().subscribe(allData => {
      console.log('allData length:', allData.length);
      // JSON Server v1 strict typing bug workaround: filter on client side
      const data = allData.filter(r => String(r.staffId) === String(user.id));
      console.log('filtered data length:', data.length);
      
      // Sort by date descending
      data.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      
      const enriched = data.map(r => ({
        ...r,
        outTime: r.outTime || 'Not Clocked Out'
      }));
      this.records.set(enriched);
      
      const today = new Date().toISOString().split('T')[0];
      console.log('Today date:', today);
      // Reverse to get the latest inserted record if there are multiple
      const reversedData = [...data].reverse();
      const todayRec = reversedData.find(r => r.date === today);
      console.log('Found todayRec:', todayRec);
      this.todayRecord.set(todayRec || null);
      console.log('Set todayRecord to:', this.todayRecord());
      
      this.loading.set(false);
    });
  }

  submitAttendance() {
    console.log('submitAttendance clicked');
    const user = this.authService.currentUser();
    console.log('Current user:', user);
    if (!user) return;

    const now = new Date();
    const newRecord: AttendanceRecord = {
      staffId: user.id,
      staffName: `${user.firstName} ${user.lastName}`,
      branchId: user.branchId || '',
      date: now.toISOString().split('T')[0],
      entryTime: now.toLocaleTimeString()
    };

    this.attendanceService.clockIn(newRecord).subscribe(() => {
      this.loadData();
    });
  }

  openManualAttendanceModal() {
    this.manualForm.reset();
    this.isManualModalOpen.set(true);
  }

  submitManualAttendance() {
    if (this.manualForm.invalid) {
      this.manualForm.markAllAsTouched();
      return;
    }

    const user = this.authService.currentUser();
    if (!user) return;

    const formValue = this.manualForm.value;
    // Format times to locale string style if needed, or just use the input value (HH:mm)
    let formatTime = (timeStr: string) => {
      if (!timeStr) return '';
      const [hours, minutes] = timeStr.split(':');
      const d = new Date();
      d.setHours(parseInt(hours, 10));
      d.setMinutes(parseInt(minutes, 10));
      return d.toLocaleTimeString();
    };

    const newRecord: AttendanceRecord = {
      staffId: user.id,
      staffName: `${user.firstName} ${user.lastName}`,
      branchId: user.branchId || '',
      date: formValue.date,
      entryTime: formatTime(formValue.entryTime)
    };

    if (formValue.outTime) {
      newRecord.outTime = formatTime(formValue.outTime);
    }

    this.attendanceService.clockIn(newRecord).subscribe(() => {
      this.loadData();
      this.isManualModalOpen.set(false);
    });
  }
}
