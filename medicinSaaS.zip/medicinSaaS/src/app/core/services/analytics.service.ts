import { Injectable, inject } from '@angular/core';
import { ApiService } from './api.service';
import { Observable, map } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AnalyticsService {
  private api = inject(ApiService);

  getDashboardStats(): Observable<any> {
    // In a real app, this might be a single endpoint. 
    // Here we'll simulate it by returning data that would normally be aggregated.
    return this.api.get<any>('/saleOrders').pipe(
      map(orders => {
        const totalRevenue = orders.reduce((acc: number, o: any) => acc + o.totalAmount, 0);
        return {
          totalRevenue,
          orderCount: orders.length,
          avgOrderValue: orders.length ? totalRevenue / orders.length : 0
        };
      })
    );
  }

  getBranchComparison(): Observable<any[]> {
    return this.api.get<any[]>('/branches').pipe(
      map(branches => {
        return branches.map(b => ({
          name: b.name,
          performance: Math.floor(Math.random() * 100)
        }));
      })
    );
  }

  getTopSellingMedicines(): Observable<any[]> {
    return this.api.get<any[]>('/medicines', { _limit: 5 });
  }
}
