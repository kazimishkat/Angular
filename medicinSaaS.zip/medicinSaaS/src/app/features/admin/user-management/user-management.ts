import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from '../../../core/services/api.service';
import { BranchService } from '../../../core/services/branch.service';
import { DataTableComponent, TableColumn } from '../../../shared/components/data-table/data-table';
import { ModalComponent } from '../../../shared/components/modal/modal';
import { FormInputComponent } from '../../../shared/components/form-input/form-input';
import { UserRole } from '../../../core/models/user.model';
import { Status } from '../../../core/models/common.model';

@Component({
  selector: 'app-user-management',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, DataTableComponent, ModalComponent, FormInputComponent],
  templateUrl: './user-management.html',
  styles: []
})
export class UserManagementComponent implements OnInit {
  private fb = inject(FormBuilder);
  private apiService = inject(ApiService);
  private branchService = inject(BranchService);

  users = signal<any[]>([]);
  branches = signal<any[]>([]);
  loading = signal(false);
  isModalOpen = signal(false);
  modalTitle = signal('Add User');

  roles = Object.values(UserRole);

  columns: TableColumn[] = [
    { key: 'id', label: 'ID', sortable: true },
    { key: 'username', label: 'Username', sortable: true },
    { key: 'email', label: 'Email' },
    { key: 'password', label: 'Password' },
    { key: 'role', label: 'Role' },
    { key: 'status', label: 'Status' }
  ];

  userForm: FormGroup = this.fb.group({
    id: [''],
    username: ['', [Validators.required]],
    password: ['password123', [Validators.required]],
    email: ['', [Validators.required, Validators.email]],
    firstName: ['', [Validators.required]],
    lastName: ['', [Validators.required]],
    role: [UserRole.BranchStaff, [Validators.required]],
    branchId: [''],
    status: [Status.Active, [Validators.required]]
  });

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    this.loading.set(true);
    this.branchService.getBranches().subscribe((b: any[]) => this.branches.set(b));
    this.loadUsers();
  }

  loadUsers() {
    this.apiService.get<any[]>('/users').subscribe((data: any[]) => {
      this.users.set(data);
      this.loading.set(false);
    });
  }

  openAddModal() {
    this.modalTitle.set('Add User');
    this.userForm.reset({ role: UserRole.BranchStaff, status: Status.Active });
    this.isModalOpen.set(true);
  }

  editUser(user: any) {
    this.modalTitle.set('Edit User');
    this.userForm.patchValue(user);
    this.isModalOpen.set(true);
  }

  saveUser() {
    if (this.userForm.invalid) {
      this.userForm.markAllAsTouched();
      return;
    }

    const user = this.userForm.value;
    if (user.id) {
      this.apiService.put<any>(`/users/${user.id}`, user).subscribe((_: any) => {
        this.loadUsers();
        this.isModalOpen.set(false);
      });
    } else {
      delete user.id;
      this.apiService.post<any>('/users', user).subscribe((_: any) => {
        this.loadUsers();
        this.isModalOpen.set(false);
      });
    }
  }

  deleteUser(id: string) {
    if (confirm('Are you sure you want to delete this user?')) {
      this.apiService.delete(`/users/${id}`).subscribe((_: any) => {
        this.loadUsers();
      });
    }
  }
}
