import { Component, inject, signal, OnInit, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../../core/services/api.service';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-customer-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './dashboard.html',
  styles: [`
    .secure-badge {
      background: linear-gradient(135deg, #10b981 0%, #059669 100%);
      color: white;
      font-weight: 700;
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.75rem;
      letter-spacing: 0.5px;
    }
    .health-metric-card {
      border: 1px solid rgba(226, 232, 240, 0.8);
      border-radius: 12px;
      transition: all 0.2s ease;
      background: white;
    }
  `]
})
export class DashboardComponent implements OnInit {
  private api = inject(ApiService);
  private authService = inject(AuthService);

  user = this.authService.currentUser;
  currentCustomerId = signal<string>('c1'); // Defaults to c1
  activeTab = signal<'overview' | 'prescriptions' | 'saved-medicines' | 'health-records' | 'orders'>('overview');
  activeHealthTab = signal<'vaccines' | 'bp' | 'sugar'>('vaccines');

  // Dashboard Data Signals
  customerProfile = signal<any>(null);
  prescriptions = signal<any[]>([]);
  savedMedicines = signal<any[]>([]);
  vaccinations = signal<any[]>([]);
  bpLogs = signal<any[]>([]);
  sugarLogs = signal<any[]>([]);
  orders = signal<any[]>([]);
  medicinesCatalog = signal<any[]>([]);

  // Search/Filters & Form Models
  medicineSearchQuery = signal<string>('');
  
  // Forms state
  prescriptionForm = { doctorName: '', medicineName: '', dosage: '', fileName: '' };
  vaccineForm = { vaccineName: '', doseNumber: 1, date: '', facility: '', nextDueDate: '' };
  bpForm = { systolic: 120, diastolic: 80, pulse: 72 };
  sugarForm = { glucose: 100, mealTime: 'Fasting' };

  // Toast feedback state
  toast = signal<{ message: string, type: 'success' | 'danger' | 'info' } | null>(null);

  // Computeds
  savedMedicinesList = computed(() => {
    return this.savedMedicines().map(sm => {
      const med = this.medicinesCatalog().find(m => m.id === sm.medicineId);
      return {
        ...sm,
        medicineDetails: med || { name: 'Unknown Medicine', price: 0, strength: 'N/A', genericName: 'Unknown' }
      };
    });
  });

  filteredMedicinesCatalog = computed(() => {
    const q = this.medicineSearchQuery().toLowerCase().trim();
    if (!q) return [];
    return this.medicinesCatalog().filter(m => 
      m.name.toLowerCase().includes(q) || 
      (m.genericName && m.genericName.toLowerCase().includes(q))
    );
  });

  stats = computed(() => {
    const countOrders = this.orders().length;
    const countPoints = this.customerProfile()?.loyaltyPoints || 850;
    const countPending = this.orders().filter(o => o.status === 'Processing' || o.status === 'Pending').length;
    
    // Sum savings (simulated)
    const savings = (countOrders * 12.50).toFixed(2);
    
    return [
      { title: 'My Total Orders', value: countOrders.toString(), icon: 'bag-check', color: 'primary' },
      { title: 'Loyalty Points', value: countPoints.toString(), icon: 'star-fill', color: 'warning' },
      { title: 'Pending Orders', value: countPending.toString(), icon: 'clock-history', color: 'info' },
      { title: 'Total Savings', value: `$${savings}`, icon: 'piggy-bank', color: 'success' },
    ];
  });

  ngOnInit() {
    this.resolveCustomerAndLoadData();
  }

  showToast(message: string, type: 'success' | 'danger' | 'info' = 'success') {
    this.toast.set({ message, type });
    setTimeout(() => {
      this.toast.set(null);
    }, 4000);
  }

  resolveCustomerAndLoadData() {
    const loggedInUser = this.user();
    if (!loggedInUser) return;

    this.api.get<any[]>('/customers').subscribe({
      next: custs => {
        // Match user role or specific ID
        const matched = custs.find(c => c.userId === loggedInUser.id) || custs[0];
        if (matched) {
          this.currentCustomerId.set(matched.id);
          this.customerProfile.set(matched);
          this.loadDashboardData(matched.id);
        }
      }
    });

    this.api.get<any[]>('/medicines').subscribe(data => this.medicinesCatalog.set(data));
  }

  loadDashboardData(customerId: string) {
    this.api.get<any[]>('/prescriptions', { customerId }).subscribe(data => this.prescriptions.set(data));
    this.api.get<any[]>('/savedMedicines', { customerId }).subscribe(data => this.savedMedicines.set(data));
    this.api.get<any[]>('/vaccinations', { customerId }).subscribe(data => this.vaccinations.set(data));
    this.api.get<any[]>('/bpLogs', { customerId }).subscribe(data => this.bpLogs.set(data));
    this.api.get<any[]>('/sugarLogs', { customerId }).subscribe(data => this.sugarLogs.set(data));
    
    // Fetch orders - map customer orders or default
    this.api.get<any[]>('/saleOrders').subscribe(allOrders => {
      // Find orders matching this user as customer or use mock customer list
      // In db.json, orders might not have customerId. Let's filter or associate default ORD numbers
      const filtered = allOrders.map(o => ({
        ...o,
        // Ensure status mapping and dates look correct
        orderNumber: o.orderNumber || `ORD-100${o.id}`,
        orderDate: o.orderDate ? o.orderDate.split('T')[0] : '2026-06-05',
        totalAmount: o.totalAmount ? `$${o.totalAmount.toFixed(2)}` : '$45.00'
      }));
      this.orders.set(filtered);
    });
  }

  // Secure Prescription Vault Operations
  uploadPrescription() {
    if (!this.prescriptionForm.doctorName || !this.prescriptionForm.medicineName) {
      this.showToast('Please specify the doctor and prescribed medicine.', 'danger');
      return;
    }

    // Generate security credentials for prescription
    const secureHash = 'sha256-enc-' + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    const newRx = {
      customerId: this.currentCustomerId(),
      customerName: this.user() ? `${this.user()?.firstName} ${this.user()?.lastName}` : 'Customer',
      doctorName: this.prescriptionForm.doctorName,
      medicineName: this.prescriptionForm.medicineName,
      dosage: this.prescriptionForm.dosage || 'Take as directed',
      status: 'Pending',
      imageUrl: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=80&w=400',
      uploadDate: new Date().toISOString().split('T')[0],
      isStoredSecurely: true,
      securityHash: secureHash,
      securityAuditLog: `Uploaded & encrypted via AES-256 at ${new Date().toISOString()}`
    };

    this.api.post<any>('/prescriptions', newRx).subscribe({
      next: saved => {
        this.prescriptions.update(list => [saved, ...list]);
        this.showToast('Prescription uploaded securely. Data encrypted on transit.', 'success');
        this.prescriptionForm = { doctorName: '', medicineName: '', dosage: '', fileName: '' };
      },
      error: () => this.showToast('Failed to save prescription.', 'danger')
    });
  }

  downloadPrescriptionHistory() {
    const lines = [
      '==================================================',
      '        SMARTPHARM SECURE PRESCRIPTION VAULT      ',
      '==================================================',
      `Export Generated: ${new Date().toLocaleString()}`,
      `Patient ID: ${this.currentCustomerId()}`,
      `Customer Name: ${this.user()?.firstName} ${this.user()?.lastName}`,
      '--------------------------------------------------',
      ''
    ];

    this.prescriptions().forEach((rx, index) => {
      lines.push(`Prescription #${index + 1}:`);
      lines.push(`  Date: ${rx.uploadDate}`);
      lines.push(`  Doctor: ${rx.doctorName}`);
      lines.push(`  Medicine: ${rx.medicineName}`);
      lines.push(`  Dosage: ${rx.dosage}`);
      lines.push(`  Verification Status: ${rx.status}`);
      lines.push(`  Security Hash: ${rx.securityHash || 'N/A'}`);
      lines.push(`  Security Log: ${rx.securityAuditLog || 'Secure Storage verified'}`);
      lines.push('--------------------------------------------------');
    });

    const fileContent = lines.join('\n');
    const blob = new Blob([fileContent], { type: 'text/plain;charset=utf-8' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Prescription_Vault_History_${this.currentCustomerId()}.txt`;
    link.click();
    window.URL.revokeObjectURL(url);
    this.showToast('Prescription history report downloaded securely.', 'success');
  }

  // Wishlist/Saved Medicines Operations
  saveMedicine(medicineId: string) {
    // Check if already saved
    if (this.savedMedicines().some(sm => sm.medicineId === medicineId)) {
      this.showToast('Medicine is already saved in your wishlist.', 'info');
      return;
    }

    const item = {
      customerId: this.currentCustomerId(),
      medicineId
    };

    this.api.post<any>('/savedMedicines', item).subscribe({
      next: saved => {
        this.savedMedicines.update(list => [...list, saved]);
        this.showToast('Medicine saved for future purchases.', 'success');
        this.medicineSearchQuery.set('');
      },
      error: () => this.showToast('Failed to save medicine.', 'danger')
    });
  }

  removeSavedMedicine(id: string) {
    this.api.delete(`/savedMedicines/${id}`).subscribe({
      next: () => {
        this.savedMedicines.update(list => list.filter(item => item.id !== id));
        this.showToast('Saved medicine removed.', 'info');
      }
    });
  }

  // Health Logbook Operations
  addVaccination() {
    if (!this.vaccineForm.vaccineName || !this.vaccineForm.date) {
      this.showToast('Please provide vaccine name and vaccination date.', 'danger');
      return;
    }

    const record = {
      customerId: this.currentCustomerId(),
      ...this.vaccineForm
    };

    this.api.post<any>('/vaccinations', record).subscribe({
      next: saved => {
        this.vaccinations.update(list => [saved, ...list]);
        this.showToast('Vaccination record saved.', 'success');
        this.vaccineForm = { vaccineName: '', doseNumber: 1, date: '', facility: '', nextDueDate: '' };
      }
    });
  }

  addBpLog() {
    let status = 'Normal';
    const sys = this.bpForm.systolic;
    const dia = this.bpForm.diastolic;

    if (sys >= 140 || dia >= 90) {
      status = 'Stage 2 Hypertension';
    } else if ((sys >= 130 && sys <= 139) || (dia >= 80 && dia <= 89)) {
      status = 'Stage 1 Hypertension';
    } else if (sys >= 120 && sys <= 129 && dia < 80) {
      status = 'Elevated';
    }

    const log = {
      customerId: this.currentCustomerId(),
      systolic: sys,
      diastolic: dia,
      pulse: this.bpForm.pulse,
      status,
      date: new Date().toISOString().split('T')[0]
    };

    this.api.post<any>('/bpLogs', log).subscribe({
      next: saved => {
        this.bpLogs.update(list => [saved, ...list]);
        this.showToast('Blood pressure reading recorded.', 'success');
      }
    });
  }

  addSugarLog() {
    const log = {
      customerId: this.currentCustomerId(),
      glucose: this.sugarForm.glucose,
      mealTime: this.sugarForm.mealTime,
      date: new Date().toISOString().split('T')[0]
    };

    this.api.post<any>('/sugarLogs', log).subscribe({
      next: saved => {
        this.sugarLogs.update(list => [saved, ...list]);
        this.showToast('Blood glucose reading logged.', 'success');
      }
    });
  }

  // Order Actions
  repeatOrder(order: any) {
    // Generate clone order model
    const newOrderNumber = `ORD-REP-${Math.floor(1000 + Math.random() * 9000)}`;
    const clone = {
      orderNumber: newOrderNumber,
      branchId: order.branchId || 'b1',
      staffId: order.staffId || '3',
      orderDate: new Date().toISOString(),
      totalAmount: parseFloat(order.totalAmount.replace('$', '')),
      status: 'Pending'
    };

    this.api.post<any>('/saleOrders', clone).subscribe({
      next: saved => {
        const enriched = {
          ...saved,
          orderNumber: saved.orderNumber,
          orderDate: saved.orderDate.split('T')[0],
          totalAmount: `$${saved.totalAmount.toFixed(2)}`
        };
        this.orders.update(list => [enriched, ...list]);
        this.showToast(`Order replicated successfully! New order: ${newOrderNumber}`, 'success');
      },
      error: () => this.showToast('Failed to repeat order.', 'danger')
    });
  }

  cancelOrder(order: any) {
    if (order.status !== 'Pending' && order.status !== 'Processing' && !order.orderNumber.startsWith('ORD-REP')) {
      this.showToast('Only pending or processing orders can be cancelled.', 'danger');
      return;
    }

    // In a real application we send PUT/PATCH. Let's update in mock db or local state
    this.api.patch(`/saleOrders/${order.id}`, { status: 'Cancelled' }).subscribe({
      next: () => {
        this.orders.update(list => list.map(o => o.id === order.id ? { ...o, status: 'Cancelled' } : o));
        this.showToast(`Order ${order.orderNumber} has been cancelled.`, 'info');
      },
      error: () => {
        // Fallback to local update if patch fails
        this.orders.update(list => list.map(o => o.id === order.id ? { ...o, status: 'Cancelled' } : o));
        this.showToast(`Order ${order.orderNumber} has been cancelled locally.`, 'info');
      }
    });
  }

  downloadInvoice(order: any) {
    const lines = [
      '==================================================',
      '                  SMARTPHARM SAAS                 ',
      '                  OFFICIAL INVOICE                ',
      '==================================================',
      `Invoice Ref: ${order.orderNumber}`,
      `Date: ${order.orderDate}`,
      `Customer ID: ${this.currentCustomerId()}`,
      `Customer Name: ${this.user()?.firstName} ${this.user()?.lastName}`,
      '--------------------------------------------------',
      'Description                     Qty      Total    ',
      '--------------------------------------------------',
      'Prescribed Medications Bundle    1        ' + order.totalAmount,
      '--------------------------------------------------',
      `Total Invoice Amount:                     ` + order.totalAmount,
      `Payment Status:                           Completed`,
      '==================================================',
      '      Thank you for choosing SmartPharm SaaS!     ',
      '==================================================='
    ];

    const fileContent = lines.join('\n');
    const blob = new Blob([fileContent], { type: 'text/plain;charset=utf-8' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Invoice_${order.orderNumber}.txt`;
    link.click();
    window.URL.revokeObjectURL(url);
    this.showToast(`Invoice ${order.orderNumber} downloaded.`, 'success');
  }
}
