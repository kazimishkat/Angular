import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../../core/services/api.service';
import { AuthService } from '../../../core/services/auth.service';
import { DataTableComponent, TableColumn } from '../../../shared/components/data-table/data-table';
import { SaleOrder } from '../../../core/models/order.model';

@Component({
  selector: 'app-staff-orders',
  standalone: true,
  imports: [CommonModule, DataTableComponent],
  templateUrl: './staff-orders.html'
})
export class StaffOrdersComponent implements OnInit {
  private api = inject(ApiService);
  private authService = inject(AuthService);

  orders = signal<SaleOrder[]>([]);
  loading = signal(false);

  columns: TableColumn[] = [
    { key: 'orderNumber', label: 'Order #', sortable: true },
    { key: 'orderDate', label: 'Date', sortable: true },
    { key: 'totalAmount', label: 'Total ($)' },
    { key: 'status', label: 'Status' }
  ];

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    this.loading.set(true);
    const user = this.authService.currentUser();
    if (!user?.branchId) return;

    this.api.get<SaleOrder[]>('/saleOrders', { branchId: user.branchId }).subscribe(data => {
      // Format totalAmount to include '$' for display
      const formatted = data.map(o => ({
        ...o,
        totalAmount: `$${o.totalAmount.toFixed(2)}` as any
      }));
      this.orders.set(formatted);
      this.loading.set(false);
    });
  }
}
