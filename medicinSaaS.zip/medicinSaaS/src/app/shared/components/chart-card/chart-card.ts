import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-chart-card',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './chart-card.html',
  styles: []
})
export class ChartCardComponent {
  @Input() title: string = '';
  @Input() height: number = 300;
}
