import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-auth-layout',
  standalone: true,
  imports: [CommonModule, RouterOutlet],
  template: `
    <div class="container-fluid p-0 overflow-hidden">
      <div class="row g-0 min-vh-100">
        <!-- Left Panel: Branding & Marketing -->
        <div class="col-lg-7 d-none d-lg-flex align-items-center justify-content-center bg-primary position-relative overflow-hidden p-5">
          <!-- Background decoration -->
          <div class="position-absolute top-0 start-0 w-100 h-100 opacity-25" style="background-image: radial-gradient(circle at 2px 2px, white 1px, transparent 0); background-size: 40px 40px;"></div>
          <div class="position-absolute bottom-0 end-0 opacity-10" style="font-size: 40rem; transform: translate(20%, 20%); line-height: 0;">
            <i class="bi bi-capsule-pill"></i>
          </div>
          
          <div class="position-relative z-1 text-white" style="max-width: 600px;">
            <div class="d-flex align-items-center gap-3 mb-5">
              <div class="bg-white rounded-4 p-3 d-flex align-items-center justify-content-center shadow-lg" style="width: 60px; height: 60px;">
                <i class="bi bi-capsule-pill text-primary fs-1"></i>
              </div>
              <h1 class="display-5 fw-bold mb-0 text-white">SmartPharm</h1>
            </div>
            
            <h2 class="display-4 fw-extrabold mb-4 lh-tight">The ultimate engine for <span class="text-info">pharmacy efficiency.</span></h2>
            <p class="lead opacity-75 mb-5 fs-4">Join 5,000+ pharmacies worldwide using our enterprise SaaS to streamline operations and boost patient care.</p>
            
            <div class="row g-4">
              <div class="col-6">
                <div class="d-flex align-items-center gap-3">
                  <i class="bi bi-check-circle-fill text-info fs-3"></i>
                  <div>
                    <h6 class="mb-0 fw-bold">Multi-Branch</h6>
                    <p class="small opacity-75 mb-0 text-white">Scale without limits</p>
                  </div>
                </div>
              </div>
              <div class="col-6">
                <div class="d-flex align-items-center gap-3">
                  <i class="bi bi-check-circle-fill text-info fs-3"></i>
                  <div>
                    <h6 class="mb-0 fw-bold">Live Inventory</h6>
                    <p class="small opacity-75 mb-0 text-white">Zero stock-outs</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div class="position-absolute bottom-0 start-0 p-5 text-white opacity-50 small">
            © 2026 SmartPharm Enterprise Solutions. All rights reserved.
          </div>
        </div>
        
        <!-- Right Panel: Auth Forms -->
        <div class="col-lg-5 d-flex align-items-center justify-content-center bg-white p-4 p-md-5">
          <div class="w-100" style="max-width: 420px;">
            <div class="d-lg-none text-center mb-5">
              <i class="bi bi-capsule-pill text-primary display-1"></i>
              <h2 class="fw-bold mt-3">SmartPharm</h2>
            </div>
            <router-outlet></router-outlet>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .fw-extrabold { font-weight: 800; }
  `]
})
export class AuthLayoutComponent {}
