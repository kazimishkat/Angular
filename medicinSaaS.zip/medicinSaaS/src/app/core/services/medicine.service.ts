import { Injectable, inject } from '@angular/core';
import { ApiService } from './api.service';
import { Medicine, Category } from '../models/medicine.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MedicineService {
  private api = inject(ApiService);

  getMedicines(params: any = {}): Observable<Medicine[]> {
    return this.api.get<Medicine[]>('/medicines', params);
  }

  getMedicineById(id: string): Observable<Medicine> {
    return this.api.get<Medicine>(`/medicines/${id}`);
  }

  createMedicine(medicine: Partial<Medicine>): Observable<Medicine> {
    return this.api.post<Medicine>('/medicines', medicine);
  }

  updateMedicine(id: string, medicine: Partial<Medicine>): Observable<Medicine> {
    return this.api.put<Medicine>(`/medicines/${id}`, medicine);
  }

  deleteMedicine(id: string): Observable<void> {
    return this.api.delete<void>(`/medicines/${id}`);
  }

  getCategories(): Observable<Category[]> {
    return this.api.get<Category[]>('/medicineCategories');
  }
}
