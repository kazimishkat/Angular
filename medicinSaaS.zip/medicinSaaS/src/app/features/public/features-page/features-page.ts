import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-features-page',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './features-page.html'
})
export class FeaturesPageComponent {}
