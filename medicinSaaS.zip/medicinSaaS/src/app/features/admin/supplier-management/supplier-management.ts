import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SupplierService } from '../../../core/services/supplier.service';
import { DataTableComponent, TableColumn } from '../../../shared/components/data-table/data-table';
import { ModalComponent } from '../../../shared/components/modal/modal';
import { FormInputComponent } from '../../../shared/components/form-input/form-input';

@Component({
  selector: 'app-supplier-management',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, DataTableComponent, ModalComponent, FormInputComponent],
  templateUrl: './supplier-management.html',
  styles: []
})
export class SupplierManagementComponent implements OnInit {
  private fb = inject(FormBuilder);
  private supplierService = inject(SupplierService);

  suppliers = signal<any[]>([]);
  loading = signal(false);
  isModalOpen = signal(false);
  modalTitle = signal('Add Supplier');

  columns: TableColumn[] = [
    { key: 'name', label: 'Supplier Name', sortable: true },
    { key: 'contactName', label: 'Contact Person' },
    { key: 'email', label: 'Email' },
    { key: 'phone', label: 'Phone' },
    { key: 'status', label: 'Status' }
  ];

  supplierForm: FormGroup = this.fb.group({
    id: [''],
    name: ['', [Validators.required]],
    contactName: ['', [Validators.required]],
    email: ['', [Validators.required, Validators.email]],
    phone: ['', [Validators.required]],
    status: ['Active', [Validators.required]]
  });

  ngOnInit() {
    this.loadSuppliers();
  }

  loadSuppliers() {
    this.loading.set(true);
    this.supplierService.getSuppliers().subscribe(data => {
      this.suppliers.set(data);
      this.loading.set(false);
    });
  }

  openAddModal() {
    this.modalTitle.set('Add Supplier');
    this.supplierForm.reset({ status: 'Active' });
    this.isModalOpen.set(true);
  }

  editSupplier(supplier: any) {
    this.modalTitle.set('Edit Supplier');
    this.supplierForm.patchValue(supplier);
    this.isModalOpen.set(true);
  }

  saveSupplier() {
    if (this.supplierForm.invalid) {
      this.supplierForm.markAllAsTouched();
      return;
    }

    const supplier = this.supplierForm.value;
    if (supplier.id) {
      this.supplierService.updateSupplier(supplier.id, supplier).subscribe(() => {
        this.loadSuppliers();
        this.isModalOpen.set(false);
      });
    } else {
      delete supplier.id;
      this.supplierService.createSupplier(supplier).subscribe(() => {
        this.loadSuppliers();
        this.isModalOpen.set(false);
      });
    }
  }
}
