import { Component, inject, signal, OnInit, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataTableComponent, TableColumn } from '../../../shared/components/data-table/data-table';
import { ApiService } from '../../../core/services/api.service';
import { AuthService } from '../../../core/services/auth.service';
import { SupplierService } from '../../../core/services/supplier.service';

@Component({
  selector: 'app-branch-inventory',
  standalone: true,
  imports: [CommonModule, DataTableComponent],
  templateUrl: './branch-inventory.html',
  styles: []
})
export class BranchInventoryComponent implements OnInit {
  private apiService = inject(ApiService);
  private authService = inject(AuthService);
  private supplierService = inject(SupplierService);

  user = this.authService.currentUser;
  
  inventoryItems = signal<any[]>([]);
  loading = signal(false);
  searchQuery = signal('');

  columns: TableColumn[] = [
    { key: 'medicineName', label: 'Medicine' },
    { key: 'supplierName', label: 'Supplier' },
    { key: 'category', label: 'Category' },
    { key: 'totalQuantity', label: 'Stock Level' },
    { key: 'status', label: 'Status' }
  ];

  filteredInventory = computed(() => {
    const query = this.searchQuery().toLowerCase();
    return this.inventoryItems().filter(item => 
      item.medicineName.toLowerCase().includes(query) || 
      (item.supplierName && item.supplierName.toLowerCase().includes(query))
    );
  });

  ngOnInit() {
    this.loadInventory();
  }

  loadInventory() {
    const user = this.user();
    const branchId = user?.branchId;
    if (!branchId) return;

    this.loading.set(true);
    this.apiService.get<any[]>(`/inventories`, { branchId }).subscribe((inv: any[]) => {
      this.apiService.get<any[]>(`/medicines`).subscribe((meds: any[]) => {
        this.supplierService.getSuppliers().subscribe((supps: any[]) => {
          const enriched = inv.map((i: any) => {
            const med = meds.find((m: any) => m.id === i.medicineId);
            const supp = supps.find((s: any) => s.id === i.supplierId);
            return {
              ...i,
              medicineName: med?.name || 'Unknown',
              category: med?.categoryName || 'N/A',
              supplierName: supp?.name || 'N/A',
              status: (i.totalQuantity < (med?.minStockLevel || 0)) ? 'Low Stock' : 'In Stock'
            };
          });
          this.inventoryItems.set(enriched);
          this.loading.set(false);
        });
      });
    });
  }
}
