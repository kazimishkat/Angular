import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './login.html',
  styles: []
})
export class LoginComponent {
  private fb = inject(FormBuilder);
  private authService = inject(AuthService);
  private router = inject(Router);

  loginForm: FormGroup = this.fb.group({
    email: ['', [Validators.required]],
    password: ['', [Validators.required, Validators.minLength(6)]],
    rememberMe: [false]
  });

  loading = false;
  errorMessage = '';

  onSubmit() {
    if (this.loginForm.invalid) {
      this.loginForm.markAllAsTouched();
      return;
    }

    this.loading = true;
    this.errorMessage = '';

    this.authService.login(this.loginForm.value).subscribe({
      next: (res) => {
        const user = res.user;
        if (user.role === 'Admin') this.router.navigate(['/admin/overview']);
        else if (user.role === 'Manager') this.router.navigate(['/manager/dashboard']);
        else if (user.role === 'BranchStaff') this.router.navigate(['/staff/pos']);
        else this.router.navigate(['/customer/dashboard']);
      },
      error: (err) => {
        if (err.status === 0 || err.status === 504) {
          this.errorMessage = 'Cannot connect to the backend server. Please ensure json-server is running.';
        } else {
          this.errorMessage = 'Invalid credentials or user not found';
        }
        this.loading = false;
      }
    });
  }
}
