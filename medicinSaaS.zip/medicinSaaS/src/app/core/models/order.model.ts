import { Status } from './common.model';

export enum OrderType {
  Sale = 'Sale',
  Purchase = 'Purchase',
  Return = 'Return'
}

export interface OrderItem {
  id: string;
  orderId: string;
  medicineId: string;
  medicineName: string;
  batchId?: string;
  quantity: number;
  unitPrice: number;
  discount: number;
  totalPrice: number;
}

export interface SaleOrder {
  id: string;
  orderNumber: string;
  customerId?: string;
  customerName?: string;
  branchId: string;
  staffId: string;
  orderDate: Date;
  subTotal: number;
  tax: number;
  discount: number;
  totalAmount: number;
  paymentMethod: string; // Cash, Card, UPI
  status: Status;
  items: OrderItem[];
}

export interface PurchaseOrder {
  id: string;
  poNumber: string;
  supplierId: string;
  branchId: string;
  orderDate: Date;
  expectedDeliveryDate: Date;
  totalAmount: number;
  status: Status;
  items: OrderItem[];
}
