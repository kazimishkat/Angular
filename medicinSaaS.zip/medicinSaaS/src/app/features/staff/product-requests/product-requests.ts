import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ProductRequestService, ProductRequest } from '../../../core/services/product-request.service';
import { MedicineService } from '../../../core/services/medicine.service';
import { SupplierService } from '../../../core/services/supplier.service';
import { AuthService } from '../../../core/services/auth.service';
import { DataTableComponent, TableColumn } from '../../../shared/components/data-table/data-table';
import { ModalComponent } from '../../../shared/components/modal/modal';
import { Medicine } from '../../../core/models/medicine.model';

@Component({
  selector: 'app-staff-product-requests',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, DataTableComponent, ModalComponent],
  templateUrl: './product-requests.html'
})
export class StaffProductRequestsComponent implements OnInit {
  private fb = inject(FormBuilder);
  private requestService = inject(ProductRequestService);
  private medicineService = inject(MedicineService);
  private supplierService = inject(SupplierService);
  private authService = inject(AuthService);

  requests = signal<ProductRequest[]>([]);
  medicines = signal<Medicine[]>([]);
  suppliers = signal<any[]>([]);
  loading = signal(false);
  isModalOpen = signal(false);
  isSupplierModalOpen = signal(false);
  selectedSupplier = signal<any>(null);
  
  columns: TableColumn[] = [
    { key: 'requestDate', label: 'Date', sortable: true },
    { key: 'medicineName', label: 'Product' },
    { key: 'quantity', label: 'Quantity' },
    { key: 'status', label: 'Status' }
  ];

  requestForm: FormGroup = this.fb.group({
    medicineName: ['', [Validators.required]],
    supplierId: ['', [Validators.required]],
    quantity: [1, [Validators.required, Validators.min(1)]]
  });

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    this.loading.set(true);
    const user = this.authService.currentUser();
    
    this.supplierService.getSuppliers().subscribe(supps => {
      this.suppliers.set(supps);
      
      this.medicineService.getMedicines().subscribe(meds => {
        this.medicines.set(meds);
        
        this.requestService.getRequests({ branchId: user?.branchId }).subscribe(reqs => {
          const enriched = reqs.map(r => ({
            ...r,
            medicineName: r.medicineName || meds.find(m => m.id === r.medicineId)?.name || 'Unknown',
            supplierName: supps.find(s => s.id === r.supplierId)?.name || 'Unknown'
          }));
          this.requests.set(enriched);
          this.loading.set(false);
        });
      });
    });
  }

  openRequestModal() {
    this.requestForm.reset({ quantity: 1 });
    this.isModalOpen.set(true);
  }

  submitRequest() {
    if (this.requestForm.invalid) {
      this.requestForm.markAllAsTouched();
      return;
    }

    const user = this.authService.currentUser();
    if (!user?.branchId || !user?.id) return;

    const formValue = this.requestForm.value;
    const newRequest: ProductRequest = {
      medicineName: formValue.medicineName,
      quantity: formValue.quantity,
      supplierId: formValue.supplierId,
      branchId: user.branchId,
      staffId: user.id,
      status: 'Pending',
      requestDate: new Date().toISOString().split('T')[0]
    };

    this.requestService.createRequest(newRequest).subscribe(() => {
      this.loadData();
      this.isModalOpen.set(false);
    });
  }

  contactSupplier(supplierId: string) {
    const supplier = this.suppliers().find(s => s.id === supplierId);
    if (supplier) {
      this.selectedSupplier.set(supplier);
      this.isSupplierModalOpen.set(true);
    }
  }
}
