import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-sales-analytics',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './sales-analytics.html'
})
export class SalesAnalyticsComponent {}
