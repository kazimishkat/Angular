import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { FormInputComponent } from '../../../shared/components/form-input/form-input';
import { BranchService } from '../../../core/services/branch.service';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink, FormInputComponent],
  templateUrl: './register.html',
  styles: []
})
export class RegisterComponent {
  private fb = inject(FormBuilder);
  private router = inject(Router);
  private branchService = inject(BranchService);
  private authService = inject(AuthService);

  registerForm: FormGroup = this.fb.group({
    firstName: ['', [Validators.required]],
    lastName: ['', [Validators.required]],
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(8)]],
    confirmPassword: ['', [Validators.required]],
    role: ['Customer', [Validators.required]],
    branchId: [''],
    agreeTerms: [false, [Validators.requiredTrue]]
  }, { validators: this.passwordMatchValidator });

  branches = signal<any[]>([]);
  loading = signal(false);
  showPassword = signal(false);

  ngOnInit() {
    this.branchService.getBranches().subscribe(data => {
      this.branches.set(data);
    });

    // Reset branchId if role is not Staff
    this.registerForm.get('role')?.valueChanges.subscribe(role => {
      if (role === 'BranchStaff') {
        this.registerForm.get('branchId')?.setValidators([Validators.required]);
      } else {
        this.registerForm.get('branchId')?.clearValidators();
        this.registerForm.get('branchId')?.setValue('');
      }
      this.registerForm.get('branchId')?.updateValueAndValidity();
    });
  }

  passwordMatchValidator(g: FormGroup) {
    return g.get('password')?.value === g.get('confirmPassword')?.value
      ? null : { mismatch: true };
  }

  onSubmit() {
    if (this.registerForm.invalid) {
      this.registerForm.markAllAsTouched();
      return;
    }

    this.loading.set(true);
    const formValue = this.registerForm.value;
    const userData = {
      firstName: formValue.firstName,
      lastName: formValue.lastName,
      username: formValue.firstName.toLowerCase() + Math.floor(Math.random() * 100),
      email: formValue.email,
      password: formValue.password,
      role: formValue.role,
      branchId: formValue.branchId
    };

    this.authService.register(userData).subscribe({
      next: (newUser) => {
        // Auto-login after registration
        this.authService.login({ email: userData.email, password: userData.password }).subscribe({
          next: (res) => {
            this.loading.set(false);
            const user = res.user;
            if (user.role === 'Admin') this.router.navigate(['/admin/overview']);
            else if (user.role === 'Manager') this.router.navigate(['/manager/dashboard']);
            else if (user.role === 'BranchStaff') this.router.navigate(['/staff/pos']);
            else this.router.navigate(['/customer/dashboard']);
          },
          error: () => {
            this.loading.set(false);
            this.router.navigate(['/auth/login']); // Fallback to manual login
          }
        });
      },
      error: () => {
        this.loading.set(false);
        alert('Registration failed. Please try again.');
      }
    });
  }

  togglePassword() {
    this.showPassword.update(v => !v);
  }
}
