import { Status } from './common.model';

export interface Category {
  id: string;
  name: string;
  description: string;
  status: Status;
}

export interface Medicine {
  id: string;
  name: string;
  genericName: string;
  categoryId: string;
  categoryName?: string;
  sku: string;
  barcode?: string;
  description?: string;
  manufacturer: string;
  strength: string;
  unitType: string; // e.g., Tablet, Syrup, Capsule
  price: number;
  costPrice: number;
  minStockLevel: number;
  status: Status;
}

export interface Batch {
  id: string;
  medicineId: string;
  batchNumber: string;
  expiryDate: Date;
  manufacturingDate: Date;
  quantity: number;
  remainingQuantity: number;
  supplierId: string;
  status: Status;
}

export interface Inventory {
  id: string;
  medicineId: string;
  branchId: string;
  totalQuantity: number;
  lastUpdated: Date;
  supplierId?: string;
  supplierName?: string;
}
