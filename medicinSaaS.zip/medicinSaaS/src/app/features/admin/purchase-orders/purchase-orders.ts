import { Component, inject, signal, OnInit, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { SupplierService } from '../../../core/services/supplier.service';
import { MedicineService } from '../../../core/services/medicine.service';
import { BranchService } from '../../../core/services/branch.service';
import { DataTableComponent, TableColumn } from '../../../shared/components/data-table/data-table';
import { ModalComponent } from '../../../shared/components/modal/modal';
import { FormInputComponent } from '../../../shared/components/form-input/form-input';
import { Status } from '../../../core/models/common.model';
import { Medicine } from '../../../core/models/medicine.model';

@Component({
  selector: 'app-purchase-orders',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, DataTableComponent, ModalComponent, FormInputComponent],
  templateUrl: './purchase-orders.html',
  styles: []
})
export class PurchaseOrdersComponent implements OnInit {
  private fb = inject(FormBuilder);
  private supplierService = inject(SupplierService);
  private medicineService = inject(MedicineService);
  private branchService = inject(BranchService);

  purchaseOrders = signal<any[]>([]);
  suppliers = signal<any[]>([]);
  medicines = signal<Medicine[]>([]);
  branches = signal<any[]>([]);
  loading = signal(false);
  isModalOpen = signal(false);
  modalTitle = signal('Create Purchase Order');

  columns: TableColumn[] = [
    { key: 'poNumber', label: 'PO Number', sortable: true },
    { key: 'supplierName', label: 'Supplier' },
    { key: 'orderDate', label: 'Order Date' },
    { key: 'totalAmount', label: 'Total Amount' },
    { key: 'status', label: 'Status' }
  ];

  poForm: FormGroup = this.fb.group({
    id: [''],
    poNumber: ['', [Validators.required]],
    supplierId: ['', [Validators.required]],
    branchId: ['', [Validators.required]],
    orderDate: [new Date().toISOString().split('T')[0], [Validators.required]],
    expectedDeliveryDate: ['', [Validators.required]],
    status: ['Pending', [Validators.required]],
    items: this.fb.array([])
  });

  get items() {
    return this.poForm.get('items') as FormArray;
  }

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    this.loading.set(true);
    this.supplierService.getSuppliers().subscribe((s: any[]) => this.suppliers.set(s));
    this.medicineService.getMedicines().subscribe((m: Medicine[]) => this.medicines.set(m));
    this.branchService.getBranches().subscribe((b: any[]) => this.branches.set(b));
    this.loadPurchaseOrders();
  }

  loadPurchaseOrders() {
    this.supplierService.getPurchaseOrders().subscribe((data: any[]) => {
      const enriched = data.map(po => ({
        ...po,
        supplierName: this.suppliers().find(s => s.id === po.supplierId)?.name || 'Unknown'
      }));
      this.purchaseOrders.set(enriched);
      this.loading.set(false);
    });
  }

  addItem() {
    const itemForm = this.fb.group({
      medicineId: ['', [Validators.required]],
      quantity: [1, [Validators.required, Validators.min(1)]],
      unitPrice: [0, [Validators.required, Validators.min(0)]],
      totalPrice: [0]
    });

    itemForm.get('quantity')?.valueChanges.subscribe(() => this.calculateItemTotal(itemForm));
    itemForm.get('unitPrice')?.valueChanges.subscribe(() => this.calculateItemTotal(itemForm));
    itemForm.get('medicineId')?.valueChanges.subscribe(id => {
      const med = this.medicines().find(m => m.id === id);
      if (med) {
        itemForm.patchValue({ unitPrice: med.costPrice });
      }
    });

    this.items.push(itemForm);
  }

  calculateItemTotal(group: FormGroup) {
    const qty = group.get('quantity')?.value || 0;
    const price = group.get('unitPrice')?.value || 0;
    group.patchValue({ totalPrice: qty * price }, { emitEvent: false });
    this.calculatePOTotal();
  }

  calculatePOTotal() {
    const total = this.items.controls.reduce((acc, ctrl) => acc + (ctrl.get('totalPrice')?.value || 0), 0);
    // You could store this in a hidden form field or a signal
  }

  removeItem(index: number) {
    this.items.removeAt(index);
    this.calculatePOTotal();
  }

  openAddModal() {
    this.modalTitle.set('Create Purchase Order');
    this.poForm.reset({ 
      orderDate: new Date().toISOString().split('T')[0], 
      status: 'Pending',
      poNumber: 'PO-' + Math.floor(1000 + Math.random() * 9000)
    });
    while (this.items.length) this.items.removeAt(0);
    this.addItem();
    this.isModalOpen.set(true);
  }

  savePO() {
    if (this.poForm.invalid) {
      this.poForm.markAllAsTouched();
      return;
    }

    const po = this.poForm.value;
    po.totalAmount = this.items.controls.reduce((acc, ctrl) => acc + (ctrl.get('totalPrice')?.value || 0), 0);

    if (po.id) {
      // update logic
    } else {
      delete po.id;
      this.supplierService.createPurchaseOrder(po).subscribe(() => {
        this.loadPurchaseOrders();
        this.isModalOpen.set(false);
      });
    }
  }
}
