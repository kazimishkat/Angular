import { Injectable, inject } from '@angular/core';
import { ApiService } from './api.service';
import { AttendanceRecord } from '../models/user.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AttendanceService {
  private api = inject(ApiService);

  getRecords(params: any = {}): Observable<AttendanceRecord[]> {
    return this.api.get<AttendanceRecord[]>('/attendanceRecords', params);
  }

  clockIn(record: AttendanceRecord): Observable<AttendanceRecord> {
    return this.api.post<AttendanceRecord>('/attendanceRecords', record);
  }

  clockOut(id: string, outTime: string): Observable<AttendanceRecord> {
    return this.api.patch<AttendanceRecord>(`/attendanceRecords/${id}`, { outTime });
  }
}
