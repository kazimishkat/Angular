import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './home.html',
  styles: [`
    .hero-section {
      padding: 100px 0;
      background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    }
    .feature-card:hover {
      transform: translateY(-10px);
      transition: all 0.3s ease;
    }
  `]
})
export class HomeComponent {
  features = [
    { title: 'Inventory Management', description: 'Real-time tracking of medicines and batches across multiple branches.', icon: 'box-seam', color: 'primary' },
    { title: 'Smart POS System', description: 'Lightning-fast sales processing with barcode and prescription support.', icon: 'cart-dash', color: 'success' },
    { title: 'Expiry Alerts', description: 'Automated notifications for medicines nearing their expiration date.', icon: 'exclamation-octagon', color: 'danger' },
    { title: 'Analytics Dashboard', description: 'Comprehensive insights into sales, financials, and inventory health.', icon: 'graph-up', color: 'info' },
  ];

  testimonials = [
    { name: 'Dr. Sarah Wilson', role: 'Pharmacy Owner', content: 'SmartPharm has transformed how we manage our 5 branches. The central control is incredible.', avatar: 'https://i.pravatar.cc/150?u=sarah' },
    { name: 'James Miller', role: 'Pharmacist', content: 'The POS is so intuitive. We reduced checkout time by 40% in just one week.', avatar: 'https://i.pravatar.cc/150?u=james' },
  ];
}
