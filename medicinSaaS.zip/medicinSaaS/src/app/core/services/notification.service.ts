import { Injectable, signal, inject } from '@angular/core';
import { ApiService } from './api.service';
import { Observable, tap } from 'rxjs';

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  isRead: boolean;
  createdAt: string;
}

@Injectable({
  providedIn: 'root'
})
export class NotificationService {
  private api = inject(ApiService);
  
  notifications = signal<Notification[]>([]);
  unreadCount = signal(0);

  loadNotifications(userId: string) {
    this.api.get<Notification[]>('/notifications', { userId, _sort: 'createdAt', _order: 'desc' }).subscribe(data => {
      this.notifications.set(data);
      this.unreadCount.set(data.filter(n => !n.isRead).length);
    });
  }

  markAsRead(id: string) {
    this.api.put<Notification>(`/notifications/${id}`, { isRead: true }).subscribe(() => {
      this.notifications.update(list => list.map(n => n.id === id ? { ...n, isRead: true } : n));
      this.unreadCount.update(count => Math.max(0, count - 1));
    });
  }

  markAllAsRead(userId: string) {
    // In a real API, this would be a single call. With json-server, we'd have to loop or use a custom route.
    this.notifications().filter(n => !n.isRead).forEach(n => this.markAsRead(n.id));
  }
}
