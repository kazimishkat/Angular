import { Injectable, inject } from '@angular/core';
import { ApiService } from './api.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BranchService {
  private api = inject(ApiService);

  getBranches(params: any = {}): Observable<any[]> {
    return this.api.get<any[]>('/branches', params);
  }

  getBranchById(id: string): Observable<any> {
    return this.api.get<any>(`/branches/${id}`);
  }

  createBranch(branch: any): Observable<any> {
    return this.api.post<any>('/branches', branch);
  }

  updateBranch(id: string, branch: any): Observable<any> {
    return this.api.put<any>(`/branches/${id}`, branch);
  }

  deleteBranch(id: string): Observable<void> {
    return this.api.delete<void>(`/branches/${id}`);
  }
}
