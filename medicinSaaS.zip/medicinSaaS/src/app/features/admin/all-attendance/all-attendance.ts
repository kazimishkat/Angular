import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AttendanceService } from '../../../core/services/attendance.service';
import { AuthService } from '../../../core/services/auth.service';
import { BranchService } from '../../../core/services/branch.service';
import { AttendanceRecord } from '../../../core/models/user.model';
import { DataTableComponent, TableColumn } from '../../../shared/components/data-table/data-table';

@Component({
  selector: 'app-all-attendance',
  standalone: true,
  imports: [CommonModule, DataTableComponent],
  templateUrl: './all-attendance.html'
})
export class AllAttendanceComponent implements OnInit {
  private attendanceService = inject(AttendanceService);
  private authService = inject(AuthService);
  private branchService = inject(BranchService);

  records = signal<AttendanceRecord[]>([]);
  loading = signal(false);

  columns: TableColumn[] = [
    { key: 'date', label: 'Date', sortable: true },
    { key: 'staffName', label: 'Staff Member', sortable: true },
    { key: 'branchName', label: 'Branch' },
    { key: 'entryTime', label: 'Clock In' },
    { key: 'outTime', label: 'Clock Out' }
  ];

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    this.loading.set(true);
    const user = this.authService.currentUser();
    
    this.branchService.getBranches().subscribe(branches => {
      // Manager only sees their branch. Admin sees all.
      const queryParams = user?.role === 'Manager' ? { branchId: user.branchId } : {};

      this.attendanceService.getRecords(queryParams).subscribe(data => {
        // Sort newest first
        data.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

        const enriched = data.map(r => ({
          ...r,
          branchName: branches.find(b => b.id === r.branchId)?.name || 'Unknown',
          outTime: r.outTime || 'Working'
        }));
        this.records.set(enriched);
        this.loading.set(false);
      });
    });
  }
}
