import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BranchService } from '../../../core/services/branch.service';
import { DataTableComponent, TableColumn } from '../../../shared/components/data-table/data-table';
import { ModalComponent } from '../../../shared/components/modal/modal';
import { FormInputComponent } from '../../../shared/components/form-input/form-input';

@Component({
  selector: 'app-branch-management',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, DataTableComponent, ModalComponent, FormInputComponent],
  templateUrl: './branch-management.html',
  styles: []
})
export class BranchManagementComponent implements OnInit {
  private fb = inject(FormBuilder);
  private branchService = inject(BranchService);

  branches = signal<any[]>([]);
  loading = signal(false);
  isModalOpen = signal(false);
  modalTitle = signal('Add Branch');

  columns: TableColumn[] = [
    { key: 'name', label: 'Branch Name', sortable: true },
    { key: 'location', label: 'Location' },
    { key: 'status', label: 'Status' }
  ];

  branchForm: FormGroup = this.fb.group({
    id: [''],
    name: ['', [Validators.required]],
    location: ['', [Validators.required]],
    status: ['Active', [Validators.required]]
  });

  ngOnInit() {
    this.loadBranches();
  }

  loadBranches() {
    this.loading.set(true);
    this.branchService.getBranches().subscribe(data => {
      this.branches.set(data);
      this.loading.set(false);
    });
  }

  openAddModal() {
    this.modalTitle.set('Add Branch');
    this.branchForm.reset({ status: 'Active' });
    this.isModalOpen.set(true);
  }

  editBranch(branch: any) {
    this.modalTitle.set('Edit Branch');
    this.branchForm.patchValue(branch);
    this.isModalOpen.set(true);
  }

  saveBranch() {
    if (this.branchForm.invalid) {
      this.branchForm.markAllAsTouched();
      return;
    }

    const branch = this.branchForm.value;
    if (branch.id) {
      this.branchService.updateBranch(branch.id, branch).subscribe(() => {
        this.loadBranches();
        this.isModalOpen.set(false);
      });
    } else {
      delete branch.id;
      this.branchService.createBranch(branch).subscribe(() => {
        this.loadBranches();
        this.isModalOpen.set(false);
      });
    }
  }

  deleteBranch(id: string) {
    if (confirm('Are you sure you want to delete this branch?')) {
      this.branchService.deleteBranch(id).subscribe(() => {
        this.loadBranches();
      });
    }
  }
}
