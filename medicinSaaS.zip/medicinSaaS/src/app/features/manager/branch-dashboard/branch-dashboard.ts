import { Component, inject, signal, OnInit, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { StatCardComponent } from '../../../shared/components/stat-card/stat-card';
import { ApiService } from '../../../core/services/api.service';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-branch-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule, StatCardComponent],
  templateUrl: './branch-dashboard.html',
  styles: []
})
export class BranchDashboardComponent implements OnInit {
  private api = inject(ApiService);
  private authService = inject(AuthService);

  user = this.authService.currentUser;
  activeTab = signal<'overview' | 'expiry' | 'forecasting' | 'staff' | 'financials' | 'customer'>('overview');

  // Database Signals
  medicines = signal<any[]>([]);
  inventories = signal<any[]>([]);
  batches = signal<any[]>([]);
  shifts = signal<any[]>([]);
  leaves = signal<any[]>([]);
  complaints = signal<any[]>([]);
  refunds = signal<any[]>([]);
  transfers = signal<any[]>([]);
  damages = signal<any[]>([]);
  cashReconciliations = signal<any[]>([]);
  saleOrders = signal<any[]>([]);
  cycleCounts = signal<any[]>([]);

  // Filters
  expiryDaysFilter = signal<number>(90);

  employeePerformance = computed(() => {
    return this.shifts().map((sh, idx) => {
      const names = ["Jane Staff", "Mike Staff2", "Kazi Islam", "John Manager"];
      const index = names.indexOf(sh.employeeName) !== -1 ? names.indexOf(sh.employeeName) : idx;
      const salesGenerated = (index + 1) * 3420;
      const attendanceScore = 94 + (index % 3) * 2;
      const rating = 4.2 + (index % 5) * 0.2;
      return {
        name: sh.employeeName,
        branchId: sh.branchId,
        salesGenerated,
        attendanceScore,
        rating: rating.toFixed(1),
        status: rating >= 4.5 ? 'Excellent' : 'Good'
      };
    });
  });

  // Form Models
  transferForm = { medicineName: '', quantity: 1, fromBranch: '', toBranch: '' };
  damageForm = { medicineName: '', quantity: 1, reason: '', reportedBy: '' };
  shiftForm = { employeeName: '', date: '', shiftType: 'Morning Shift (08:00 - 16:00)', branchId: '' };
  reconciliationForm = { date: '', openingCash: 500, closingCash: 500, physicalCash: 500, branchId: '' };

  ngOnInit() {
    const userBranchId = this.user()?.branchId || 'b1';
    this.transferForm.fromBranch = userBranchId;
    this.shiftForm.branchId = userBranchId;
    this.reconciliationForm.branchId = userBranchId;
    this.loadAllData();
  }

  loadAllData() {
    const userBranchId = this.user()?.branchId || 'b1';

    this.api.get<any[]>('/medicines').subscribe(data => this.medicines.set(data));
    
    this.api.get<any[]>('/inventories', { branchId: userBranchId }).subscribe(data => this.inventories.set(data));
    
    this.api.get<any[]>('/batches', { branchId: userBranchId }).subscribe(data => this.batches.set(data));
    
    this.api.get<any[]>('/shifts', { branchId: userBranchId }).subscribe(data => this.shifts.set(data));
    
    this.api.get<any[]>('/leaves', { branchId: userBranchId }).subscribe(data => this.leaves.set(data));
    
    this.api.get<any[]>('/complaints', { branchId: userBranchId }).subscribe(data => this.complaints.set(data));
    
    this.api.get<any[]>('/refunds', { branchId: userBranchId }).subscribe(data => this.refunds.set(data));
    
    // Transfers involve either direction
    this.api.get<any[]>('/transfers').subscribe(data => {
      const filtered = data.filter(t => t.fromBranch === userBranchId || t.toBranch === userBranchId);
      this.transfers.set(filtered);
    });
    
    this.api.get<any[]>('/damages', { branchId: userBranchId }).subscribe(data => this.damages.set(data));
    
    this.api.get<any[]>('/cashReconciliations', { branchId: userBranchId }).subscribe(data => this.cashReconciliations.set(data));
    
    this.api.get<any[]>('/saleOrders', { branchId: userBranchId }).subscribe(data => this.saleOrders.set(data));
    
    this.api.get<any[]>('/cycleCounts', { branchId: userBranchId }).subscribe(data => this.cycleCounts.set(data));
  }

  // Calculated KPI stats
  kpis = computed(() => {
    const orders = this.saleOrders();
    const inv = this.inventories();
    const meds = this.medicines();

    const todaySales = orders.reduce((sum, o) => sum + (o.totalAmount || 0), 0);
    const monthlyRev = todaySales * 18.5; // Simulated monthly revenue based on scale
    const customerCount = Math.floor(orders.length * 12.4) + 120;
    
    // count medicines below min stock
    let lowStockCount = 0;
    inv.forEach(i => {
      const med = meds.find(m => m.id === i.medicineId);
      if (med && i.totalQuantity < (med.minStockLevel || 0)) {
        lowStockCount++;
      }
    });

    return [
      { title: "Today's Sales", value: `$${todaySales.toFixed(2)}`, icon: 'cart-check', color: 'primary' },
      { title: 'Monthly Revenue', value: `$${monthlyRev.toFixed(2)}`, icon: 'cash-coin', color: 'success' },
      { title: 'Customer Count', value: `${customerCount}`, icon: 'people', color: 'info' },
      { title: 'Low Stock Items', value: `${lowStockCount}`, icon: 'exclamation-triangle', color: 'danger' }
    ];
  });

  // Top Medicines List
  topMedicines = computed(() => {
    return [
      { name: 'Paracetamol 500mg', units: 1420, revenue: 7810, rank: '01' },
      { name: 'Amoxicillin 250mg', units: 920, revenue: 11040, rank: '02' },
      { name: 'Napa Tablet', units: 850, revenue: 8500, rank: '03' }
    ];
  });

  // Expiry Calculations (30, 60, 90 days)
  expiryAlertsList = computed(() => {
    const now = new Date();
    return this.batches().map(b => {
      const med = this.medicines().find(m => m.id === b.medicineId);
      const expDate = new Date(b.expiryDate);
      const diffTime = expDate.getTime() - now.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      let status = 'Safe';
      if (diffDays <= 0) status = 'Expired';
      else if (diffDays <= 30) status = 'Expiring (<30 Days)';
      else if (diffDays <= 60) status = 'Expiring (<60 Days)';
      else if (diffDays <= 90) status = 'Expiring (<90 Days)';

      return {
        ...b,
        medicineName: med?.name || 'Unknown Medicine',
        daysLeft: diffDays,
        expiryStatus: status
      };
    }).filter(b => b.daysLeft <= this.expiryDaysFilter());
  });

  // Shortage Forecasts
  shortageForecasts = computed(() => {
    return this.inventories().map(i => {
      const med = this.medicines().find(m => m.id === i.medicineId);
      if (!med) return null;
      const dailyUsage = Math.floor(Math.random() * 8) + 2;
      const daysRemaining = Math.floor(i.totalQuantity / dailyUsage);
      return {
        medicineName: med.name,
        branchId: i.branchId,
        currentStock: i.totalQuantity,
        dailyUsage,
        daysRemaining,
        severity: daysRemaining < 10 ? 'High' : daysRemaining < 20 ? 'Medium' : 'Low'
      };
    }).filter(f => f !== null && f.daysRemaining < 30);
  });

  // Actions
  disposeStock(batchId: string) {
    const batch = this.batches().find(b => b.id === batchId);
    if (!batch) return;
    this.api.put(`/batches/${batchId}`, { ...batch, quantity: 0, recallStatus: 'Disposed' }).subscribe(() => {
      this.batches.update(list => list.map(b => b.id === batchId ? { ...b, quantity: 0, recallStatus: 'Disposed' } : b));
    });
  }

  recallBatch(batchId: string) {
    const batch = this.batches().find(b => b.id === batchId);
    if (!batch) return;
    this.api.put(`/batches/${batchId}`, { ...batch, recallStatus: 'Recalled' }).subscribe(() => {
      this.batches.update(list => list.map(b => b.id === batchId ? { ...b, recallStatus: 'Recalled' } : b));
    });
  }

  approveLeave(leaveId: string) {
    const leave = this.leaves().find(l => l.id === leaveId);
    if (!leave) return;
    this.api.put(`/leaves/${leaveId}`, { ...leave, status: 'Approved' }).subscribe(() => {
      this.leaves.update(list => list.map(l => l.id === leaveId ? { ...l, status: 'Approved' } : l));
    });
  }

  rejectLeave(leaveId: string) {
    const leave = this.leaves().find(l => l.id === leaveId);
    if (!leave) return;
    this.api.put(`/leaves/${leaveId}`, { ...leave, status: 'Rejected' }).subscribe(() => {
      this.leaves.update(list => list.map(l => l.id === leaveId ? { ...l, status: 'Rejected' } : l));
    });
  }

  approveRefund(refundId: string) {
    const refund = this.refunds().find(r => r.id === refundId);
    if (!refund) return;
    this.api.put(`/refunds/${refundId}`, { ...refund, status: 'Approved' }).subscribe(() => {
      this.refunds.update(list => list.map(r => r.id === refundId ? { ...r, status: 'Approved' } : r));
    });
  }

  rejectRefund(refundId: string) {
    const refund = this.refunds().find(r => r.id === refundId);
    if (!refund) return;
    this.api.put(`/refunds/${refundId}`, { ...refund, status: 'Rejected' }).subscribe(() => {
      this.refunds.update(list => list.map(r => r.id === refundId ? { ...r, status: 'Rejected' } : r));
    });
  }

  resolveComplaint(complaintId: string) {
    const comp = this.complaints().find(c => c.id === complaintId);
    if (!comp) return;
    this.api.put(`/complaints/${complaintId}`, { ...comp, status: 'Resolved' }).subscribe(() => {
      this.complaints.update(list => list.map(c => c.id === complaintId ? { ...c, status: 'Resolved' } : c));
    });
  }

  autoGeneratePurchaseRequests() {
    const userBranchId = this.user()?.branchId || 'b1';
    let count = 0;
    this.inventories().forEach(i => {
      const med = this.medicines().find(m => m.id === i.medicineId);
      if (med && i.totalQuantity < (med.minStockLevel || 0)) {
        const qtyNeeded = (med.minStockLevel || 100) * 2 - i.totalQuantity;
        const req = {
          medicineId: i.medicineId,
          medicineName: med.name,
          quantity: qtyNeeded,
          branchId: userBranchId,
          staffId: this.user()?.id || '2',
          supplierId: 's1',
          supplierName: 'Global Pharma Wholesales',
          status: 'Pending',
          requestDate: new Date().toISOString().split('T')[0]
        };
        this.api.post<any>('/productRequests', req).subscribe();
        count++;
      }
    });
    alert(`Auto-generated ${count} purchase requests for items below minimum stock level in branch ${userBranchId}!`);
    setTimeout(() => this.loadAllData(), 1000);
  }

  submitTransfer() {
    const userBranchId = this.user()?.branchId || 'b1';
    if (!this.transferForm.medicineName || !this.transferForm.fromBranch || !this.transferForm.toBranch) return;
    const newTransfer = {
      medicineName: this.transferForm.medicineName,
      quantity: this.transferForm.quantity,
      fromBranch: this.transferForm.fromBranch,
      toBranch: this.transferForm.toBranch,
      status: 'Pending',
      date: new Date().toISOString().split('T')[0]
    };
    this.api.post<any>('/transfers', newTransfer).subscribe(saved => {
      this.transfers.update(list => [saved, ...list]);
      this.transferForm = { medicineName: '', quantity: 1, fromBranch: userBranchId, toBranch: '' };
    });
  }

  submitDamage() {
    const userBranchId = this.user()?.branchId || 'b1';
    if (!this.damageForm.medicineName || !this.damageForm.reason) return;
    const newDamage = {
      medicineName: this.damageForm.medicineName,
      quantity: this.damageForm.quantity,
      reason: this.damageForm.reason,
      reportedBy: this.damageForm.reportedBy || this.user()?.username || 'Manager',
      date: new Date().toISOString().split('T')[0],
      branchId: userBranchId
    };
    this.api.post<any>('/damages', newDamage).subscribe(saved => {
      this.damages.update(list => [saved, ...list]);
      this.damageForm = { medicineName: '', quantity: 1, reason: '', reportedBy: '' };
    });
  }

  reconcileCash(id: string) {
    const record = this.cashReconciliations().find(c => c.id === id);
    if (!record) return;
    this.api.put(`/cashReconciliations/${id}`, { ...record, status: 'Reconciled', discrepancy: 0, physicalCash: record.closingCash }).subscribe(() => {
      this.cashReconciliations.update(list => list.map(c => c.id === id ? { ...c, status: 'Reconciled', discrepancy: 0, physicalCash: c.closingCash } : c));
    });
  }

  performCycleCount(id: string, actualQty: number) {
    const record = this.cycleCounts().find(c => c.id === id);
    if (!record) return;
    this.api.put(`/cycleCounts/${id}`, { ...record, actualQty, status: 'Completed' }).subscribe(() => {
      this.cycleCounts.update(list => list.map(c => c.id === id ? { ...c, actualQty, status: 'Completed' } : c));
    });
  }

  submitShift() {
    if (!this.shiftForm.employeeName || !this.shiftForm.date) return;
    this.api.post<any>('/shifts', this.shiftForm).subscribe(saved => {
      this.shifts.update(list => [saved, ...list]);
      this.shiftForm = { employeeName: '', date: '', shiftType: 'Morning Shift (08:00 - 16:00)', branchId: this.user()?.branchId || 'b1' };
    });
  }

  submitReconciliation() {
    if (!this.reconciliationForm.date) return;
    const discrepancy = this.reconciliationForm.physicalCash - this.reconciliationForm.closingCash;
    const newRecord = {
      ...this.reconciliationForm,
      discrepancy,
      status: 'Pending'
    };
    this.api.post<any>('/cashReconciliations', newRecord).subscribe(saved => {
      this.cashReconciliations.update(list => [saved, ...list]);
      this.reconciliationForm = { date: '', openingCash: 500, closingCash: 500, physicalCash: 500, branchId: this.user()?.branchId || 'b1' };
    });
  }
}
