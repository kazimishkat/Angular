import { Injectable, inject } from '@angular/core';
import { ApiService } from './api.service';
import { Inventory } from '../models/medicine.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class InventoryService {
  private api = inject(ApiService);

  getInventories(params: any = {}): Observable<Inventory[]> {
    return this.api.get<Inventory[]>('/inventories', params);
  }

  getInventoryByBranch(branchId: string): Observable<Inventory[]> {
    return this.api.get<Inventory[]>('/inventories', { branchId });
  }

  updateStock(id: string, quantity: number): Observable<Inventory> {
    return this.api.put<Inventory>(`/inventories/${id}`, { totalQuantity: quantity });
  }

  createInventory(inventory: any): Observable<Inventory> {
    return this.api.post<Inventory>('/inventories', inventory);
  }

  getStockMovements(params: any = {}): Observable<any[]> {
    return this.api.get<any[]>('/stockMovements', params);
  }

  getExpiryAlerts(): Observable<any[]> {
    return this.api.get<any[]>('/expiryAlerts');
  }
}
