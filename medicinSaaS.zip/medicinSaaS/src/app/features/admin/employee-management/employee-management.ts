import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { EmployeeService } from '../../../core/services/employee.service';
import { BranchService } from '../../../core/services/branch.service';
import { DataTableComponent, TableColumn } from '../../../shared/components/data-table/data-table';
import { ModalComponent } from '../../../shared/components/modal/modal';
import { FormInputComponent } from '../../../shared/components/form-input/form-input';

@Component({
  selector: 'app-employee-management',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, DataTableComponent, ModalComponent, FormInputComponent],
  templateUrl: './employee-management.html',
  styles: []
})
export class EmployeeManagementComponent implements OnInit {
  private fb = inject(FormBuilder);
  private employeeService = inject(EmployeeService);
  private branchService = inject(BranchService);

  employees = signal<any[]>([]);
  branches = signal<any[]>([]);
  loading = signal(false);
  isModalOpen = signal(false);
  modalTitle = signal('Add Employee');

  columns: TableColumn[] = [
    { key: 'designation', label: 'Designation', sortable: true },
    { key: 'salary', label: 'Salary' },
    { key: 'joinDate', label: 'Join Date' },
    { key: 'branchId', label: 'Branch ID' }
  ];

  employeeForm: FormGroup = this.fb.group({
    id: [''],
    designation: ['', [Validators.required]],
    salary: [0, [Validators.required, Validators.min(0)]],
    joinDate: ['', [Validators.required]],
    branchId: ['', [Validators.required]]
  });

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    this.loading.set(true);
    this.branchService.getBranches().subscribe(branches => {
      this.branches.set(branches);
      this.loadEmployees();
    });
  }

  loadEmployees() {
    this.employeeService.getEmployees().subscribe(data => {
      this.employees.set(data);
      this.loading.set(false);
    });
  }

  openAddModal() {
    this.modalTitle.set('Add Employee');
    this.employeeForm.reset({ salary: 0 });
    this.isModalOpen.set(true);
  }

  editEmployee(employee: any) {
    this.modalTitle.set('Edit Employee');
    this.employeeForm.patchValue(employee);
    this.isModalOpen.set(true);
  }

  saveEmployee() {
    if (this.employeeForm.invalid) {
      this.employeeForm.markAllAsTouched();
      return;
    }

    const employee = this.employeeForm.value;
    if (employee.id) {
      this.employeeService.updateEmployee(employee.id, employee).subscribe(() => {
        this.loadEmployees();
        this.isModalOpen.set(false);
      });
    } else {
      delete employee.id;
      this.employeeService.createEmployee(employee).subscribe(() => {
        this.loadEmployees();
        this.isModalOpen.set(false);
      });
    }
  }

  deleteEmployee(id: string) {
    if (confirm('Are you sure you want to delete this employee?')) {
      this.employeeService.deleteEmployee(id).subscribe(() => {
        this.loadEmployees();
      });
    }
  }
}
