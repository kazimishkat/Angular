import { Component, inject, signal, OnInit, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { InventoryService } from '../../../core/services/inventory.service';
import { MedicineService } from '../../../core/services/medicine.service';
import { SupplierService } from '../../../core/services/supplier.service';
import { AuthService } from '../../../core/services/auth.service';
import { DataTableComponent, TableColumn } from '../../../shared/components/data-table/data-table';
import { Medicine } from '../../../core/models/medicine.model';

@Component({
  selector: 'app-staff-inventory',
  standalone: true,
  imports: [CommonModule, DataTableComponent],
  templateUrl: './staff-inventory.html'
})
export class StaffInventoryComponent implements OnInit {
  private inventoryService = inject(InventoryService);
  private medicineService = inject(MedicineService);
  private supplierService = inject(SupplierService);
  private authService = inject(AuthService);
  private router = inject(Router);

  inventoryItems = signal<any[]>([]);
  expiringSoon = signal<any[]>([]);
  loading = signal(false);
  searchQuery = signal('');

  columns: TableColumn[] = [
    { key: 'medicineName', label: 'Medicine', sortable: true },
    { key: 'supplierName', label: 'Supplier' },
    { key: 'sku', label: 'SKU' },
    { key: 'totalQuantity', label: 'In Stock' },
    { key: 'expiryDate', label: 'Expiry Date', sortable: true },
    { key: 'status', label: 'Status' }
  ];

  filteredInventory = computed(() => {
    const query = this.searchQuery().toLowerCase();
    return this.inventoryItems().filter(item => 
      item.medicineName.toLowerCase().includes(query) || 
      (item.supplierName && item.supplierName.toLowerCase().includes(query))
    );
  });

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    this.loading.set(true);
    const user = this.authService.currentUser();
    if (!user?.branchId) return;

    this.medicineService.getMedicines().subscribe(meds => {
      this.supplierService.getSuppliers().subscribe(supps => {
        this.inventoryService.getInventoryByBranch(user.branchId!).subscribe((inv: any[]) => {
          const enriched = inv.map(i => {
            const med = meds.find(m => m.id === i.medicineId);
            const supp = supps.find((s: any) => s.id === i.supplierId);
            return {
              ...i,
              medicineName: med?.name || 'Unknown',
              supplierName: supp?.name || 'N/A',
              sku: med?.sku || '-',
              status: this.calculateStatus(i.totalQuantity, med?.minStockLevel || 10, i.expiryDate)
            };
          });
          
          this.inventoryItems.set(enriched);
          
          // Find items expiring within 30 days
          const thirtyDaysFromNow = new Date();
          thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30);
          
          const expiring = enriched.filter(item => {
            if (!item.expiryDate) return false;
            return new Date(item.expiryDate) <= thirtyDaysFromNow;
          });
          this.expiringSoon.set(expiring);
          
          this.loading.set(false);
        });
      });
    });
  }

  private calculateStatus(qty: number, minStock: number, expiryDate: string): string {
    if (qty <= 0) return 'Out of Stock';
    if (qty <= minStock) return 'Low Stock';
    if (expiryDate && new Date(expiryDate) < new Date()) return 'Expired';
    return 'In Stock';
  }

  goToSell() {
    this.router.navigate(['/staff/pos']);
  }

  goToRequest() {
    this.router.navigate(['/staff/requests']);
  }
}
