import { Injectable, inject } from '@angular/core';
import { ApiService } from './api.service';
import { Observable } from 'rxjs';

export interface ProductRequest {
  id?: string;
  medicineId?: string;
  medicineName?: string;
  quantity: number;
  branchId: string;
  staffId: string;
  supplierId: string;
  supplierName?: string;
  status: 'Pending' | 'Accepted' | 'Rejected' | 'Ordered';
  requestDate: string;
}

@Injectable({
  providedIn: 'root'
})
export class ProductRequestService {
  private api = inject(ApiService);

  getRequests(params: any = {}): Observable<ProductRequest[]> {
    return this.api.get<ProductRequest[]>('/productRequests', params);
  }

  createRequest(request: ProductRequest): Observable<ProductRequest> {
    return this.api.post<ProductRequest>('/productRequests', request);
  }

  updateRequest(id: string, request: Partial<ProductRequest>): Observable<ProductRequest> {
    return this.api.put<ProductRequest>(`/productRequests/${id}`, request);
  }
}
