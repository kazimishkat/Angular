import { Routes } from '@angular/router';
import { authGuard, roleGuard } from './core/guards/auth.guard';
import { UserRole } from './core/models/user.model';

export const routes: Routes = [
  // Public Routes
  {
    path: '',
    loadComponent: () => import('./layout/public-layout/public-layout').then(m => m.PublicLayoutComponent),
    children: [
      { path: '', loadComponent: () => import('./features/public/home/home').then(m => m.HomeComponent) },
      { path: 'features', loadComponent: () => import('./features/public/features-page/features-page').then(m => m.FeaturesPageComponent) },
      { path: 'pricing', loadComponent: () => import('./features/public/pricing/pricing').then(m => m.PricingComponent) },
      { path: 'about', loadComponent: () => import('./features/public/about/about').then(m => m.AboutComponent) },
      { path: 'contact', loadComponent: () => import('./features/public/contact/contact').then(m => m.ContactComponent) },
    ]
  },

  // Auth Routes
  {
    path: 'auth',
    loadComponent: () => import('./layout/auth-layout/auth-layout').then(m => m.AuthLayoutComponent),
    children: [
      { path: 'login', loadComponent: () => import('./features/auth/login/login').then(m => m.LoginComponent) },
      { path: 'register', loadComponent: () => import('./features/auth/register/register').then(m => m.RegisterComponent) },
      { path: 'forgot-password', loadComponent: () => import('./features/auth/forgot-password/forgot-password').then(m => m.ForgotPasswordComponent) },
    ]
  },

  // Dashboard Routes (Admin, Manager, Staff)
  {
    path: '',
    loadComponent: () => import('./layout/admin-layout/admin-layout').then(m => m.AdminLayoutComponent),
    canActivate: [authGuard],
    children: [
      // Admin Dashboard
      {
        path: 'admin',
        canActivate: [roleGuard],
        data: { roles: [UserRole.Admin] },
        children: [
          { path: 'overview', loadComponent: () => import('./features/admin/dashboard/dashboard').then(m => m.DashboardComponent) },
          { path: 'users', loadComponent: () => import('./features/admin/user-management/user-management').then(m => m.UserManagementComponent) },
          { path: 'branches', loadComponent: () => import('./features/admin/branch-management/branch-management').then(m => m.BranchManagementComponent) },
          { path: 'employees', loadComponent: () => import('./features/admin/employee-management/employee-management').then(m => m.EmployeeManagementComponent) },
          { path: 'medicines', loadComponent: () => import('./features/admin/medicine-management/medicine-management').then(m => m.MedicineManagementComponent) },
          { path: 'inventory', loadComponent: () => import('./features/admin/inventory-dashboard/inventory-dashboard').then(m => m.InventoryDashboardComponent) },
          { path: 'suppliers', loadComponent: () => import('./features/admin/supplier-management/supplier-management').then(m => m.SupplierManagementComponent) },
          { path: 'purchase-orders', loadComponent: () => import('./features/admin/purchase-orders/purchase-orders').then(m => m.PurchaseOrdersComponent) },
          { path: 'sales-analytics', loadComponent: () => import('./features/admin/sales-analytics/sales-analytics').then(m => m.SalesAnalyticsComponent) },
          { path: 'settings', loadComponent: () => import('./features/admin/app-settings/app-settings').then(m => m.AppSettingsComponent) },
          { path: 'requests', loadComponent: () => import('./features/manager/product-requests/product-requests').then(m => m.ManagerProductRequestsComponent) },
          { path: 'attendance', loadComponent: () => import('./features/admin/all-attendance/all-attendance').then(m => m.AllAttendanceComponent) },
        ]
      },
      // Manager Dashboard
      {
        path: 'manager',
        canActivate: [roleGuard],
        data: { roles: [UserRole.Manager] },
        children: [
          { path: 'dashboard', loadComponent: () => import('./features/manager/branch-dashboard/branch-dashboard').then(m => m.BranchDashboardComponent) },
          { path: 'inventory', loadComponent: () => import('./features/manager/branch-inventory/branch-inventory').then(m => m.BranchInventoryComponent) },
          { path: 'branches', loadComponent: () => import('./features/admin/branch-management/branch-management').then(m => m.BranchManagementComponent) },
          { path: 'employees', loadComponent: () => import('./features/admin/employee-management/employee-management').then(m => m.EmployeeManagementComponent) },
          { path: 'purchase-orders', loadComponent: () => import('./features/admin/purchase-orders/purchase-orders').then(m => m.PurchaseOrdersComponent) },
          { path: 'requests', loadComponent: () => import('./features/manager/product-requests/product-requests').then(m => m.ManagerProductRequestsComponent) },
          { path: 'attendance', loadComponent: () => import('./features/admin/all-attendance/all-attendance').then(m => m.AllAttendanceComponent) },
        ]
      },
      // Staff Dashboard
      {
        path: 'staff',
        canActivate: [roleGuard],
        data: { roles: [UserRole.BranchStaff] },
        children: [
          { path: 'pos', loadComponent: () => import('./features/staff/pos/pos').then(m => m.PosComponent) },
          { path: 'portal', loadComponent: () => import('./features/staff/pharmacist-portal/pharmacist-portal').then(m => m.PharmacistPortalComponent) },
          { path: 'inventory', loadComponent: () => import('./features/staff/staff-inventory/staff-inventory').then(m => m.StaffInventoryComponent) },
          { path: 'requests', loadComponent: () => import('./features/staff/product-requests/product-requests').then(m => m.StaffProductRequestsComponent) },
          { path: 'orders', loadComponent: () => import('./features/staff/staff-orders/staff-orders').then(m => m.StaffOrdersComponent) },
          { path: 'attendance', loadComponent: () => import('./features/staff/staff-attendance/staff-attendance').then(m => m.StaffAttendanceComponent) },
        ]
      }
    ]
  },

  // Customer Portal
  {
    path: 'customer',
    loadComponent: () => import('./layout/admin-layout/admin-layout').then(m => m.AdminLayoutComponent), // Reuse admin layout for dashboard feel or create custom
    canActivate: [authGuard, roleGuard],
    data: { roles: [UserRole.Customer] },
    children: [
      { path: 'dashboard', loadComponent: () => import('./features/customer/dashboard/dashboard').then(m => m.DashboardComponent) },
      { path: 'orders', loadComponent: () => import('./features/customer/my-orders/my-orders').then(m => m.MyOrdersComponent) },
    ]
  },

  { path: '**', redirectTo: '' }
];
