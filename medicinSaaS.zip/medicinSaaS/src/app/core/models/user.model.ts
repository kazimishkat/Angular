import { Status } from './common.model';

export enum UserRole {
  Admin = 'Admin',
  Manager = 'Manager',
  BranchStaff = 'BranchStaff',
  Customer = 'Customer'
}

export interface User {
  id: string;
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  role: UserRole;
  branchId?: string;
  phoneNumber?: string;
  status: Status;
  lastLogin?: Date;
  profileImage?: string;
}

export interface Permission {
  id: string;
  name: string;
  code: string;
  description: string;
}

export interface Role {
  id: string;
  name: UserRole;
  permissions: Permission[];
}

export interface Customer extends User {
  loyaltyPoints: number;
  totalOrders: number;
  lastOrderDate?: string;
}

export interface AttendanceRecord {
  id?: string;
  staffId: string;
  staffName?: string;
  branchId: string;
  date: string;
  entryTime: string;
  outTime?: string;
}
