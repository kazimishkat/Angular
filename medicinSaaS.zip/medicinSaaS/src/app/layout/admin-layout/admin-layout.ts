import { Component, inject, computed, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { UserRole } from '../../core/models/user.model';
import { NotificationDropdownComponent } from '../../shared/components/notification-dropdown/notification-dropdown';

@Component({
  selector: 'app-admin-layout',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive, NotificationDropdownComponent],
  templateUrl: './admin-layout.html',
  styles: [`
    :host { display: block; }
    .sidebar {
      width: var(--sidebar-width);
      height: 100vh;
      position: fixed;
      left: 0;
      top: 0;
      z-index: 1050;
      background: #ffffff;
      border-right: 1px solid rgba(0,0,0,0.05);
      transition: transform 0.3s ease;
    }
    .main-wrapper {
      margin-left: var(--sidebar-width);
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      transition: margin-left 0.3s ease;
    }
    .header {
      height: var(--header-height);
      position: sticky;
      top: 0;
      z-index: 1000;
    }
    @media (max-width: 991.98px) {
      .sidebar { transform: translateX(-100%); }
      .sidebar.show { transform: translateX(0); }
      .main-wrapper { margin-left: 0; }
    }
    .sidebar-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0,0,0,0.5);
      z-index: 1040;
    }
  `]
})
export class AdminLayoutComponent {
  authService = inject(AuthService);
  user = this.authService.currentUser;
  isSidebarOpen = signal(false);

  menuItems = [
    { label: 'Overview', icon: 'grid-1x2', route: '/admin/overview', roles: [UserRole.Admin] },
    { label: 'All Users', icon: 'person-vcard', route: '/admin/users', roles: [UserRole.Admin] },
    { label: 'Branch Analytics', icon: 'building-gear', route: '/manager/dashboard', roles: [UserRole.Manager] },
    { label: 'POS Terminal', icon: 'cart-dash', route: '/staff/pos', roles: [UserRole.BranchStaff] },
    { label: 'Pharmacist Portal', icon: 'heart-pulse', route: '/staff/portal', roles: [UserRole.BranchStaff] },
    { label: 'Branches', icon: 'geo-alt', route: '/admin/branches', roles: [UserRole.Admin] },
    { label: 'Branches', icon: 'geo-alt', route: '/manager/branches', roles: [UserRole.Manager] },
    { label: 'Staff Management', icon: 'people', route: '/admin/employees', roles: [UserRole.Admin] },
    { label: 'Staff Management', icon: 'people', route: '/manager/employees', roles: [UserRole.Manager] },
    { label: 'Staff Attendance', icon: 'clock-history', route: '/admin/attendance', roles: [UserRole.Admin] },
    { label: 'Staff Attendance', icon: 'clock-history', route: '/manager/attendance', roles: [UserRole.Manager] },
    { label: 'My Attendance', icon: 'clock', route: '/staff/attendance', roles: [UserRole.BranchStaff] },
    { label: 'Medicine Catalog', icon: 'capsule', route: '/admin/medicines', roles: [UserRole.Admin] },
    { label: 'Inventory', icon: 'box-seam', route: '/admin/inventory', roles: [UserRole.Admin] },
    { label: 'Inventory', icon: 'box-seam', route: '/manager/inventory', roles: [UserRole.Manager] },
    { label: 'Inventory', icon: 'box-seam', route: '/staff/inventory', roles: [UserRole.BranchStaff] },
    { label: 'Suppliers', icon: 'truck', route: '/admin/suppliers', roles: [UserRole.Admin] },
    { label: 'Purchase Orders', icon: 'file-earmark-text', route: '/admin/purchase-orders', roles: [UserRole.Admin] },
    { label: 'Purchase Orders', icon: 'file-earmark-text', route: '/manager/purchase-orders', roles: [UserRole.Manager] },
    { label: 'Sales Reports', icon: 'graph-up', route: '/admin/sales-analytics', roles: [UserRole.Admin] },
    { label: 'Settings', icon: 'sliders', route: '/admin/settings', roles: [UserRole.Admin] },
    { label: 'Product Requests', icon: 'box-seam', route: '/staff/requests', roles: [UserRole.BranchStaff] },
    { label: 'Product Requests', icon: 'box-seam', route: '/manager/requests', roles: [UserRole.Manager] },
    { label: 'Product Requests', icon: 'box-seam', route: '/admin/requests', roles: [UserRole.Admin] },
    { label: 'Customer Orders', icon: 'receipt', route: '/staff/orders', roles: [UserRole.BranchStaff] },
  ];

  filteredMenuItems = computed(() => {
    const userRole = this.user()?.role;
    return this.menuItems.filter(item => userRole && item.roles.includes(userRole));
  });

  toggleSidebar() {
    this.isSidebarOpen.update(v => !v);
  }

  logout() {
    this.authService.logout();
  }
}
