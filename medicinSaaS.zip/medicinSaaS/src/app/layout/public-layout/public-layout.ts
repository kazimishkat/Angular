import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet, RouterLink } from '@angular/router';
import { BranchService } from '../../core/services/branch.service';

@Component({
  selector: 'app-public-layout',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink],
  templateUrl: './public-layout.html',
  styles: []
})
export class PublicLayoutComponent implements OnInit {
  private branchService = inject(BranchService);
  branches = signal<any[]>([]);

  ngOnInit() {
    this.branchService.getBranches().subscribe(data => {
      this.branches.set(data);
    });
  }
}
