import { Component, Input, Output, EventEmitter, OnChanges, SimpleChanges, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-modal',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './modal.html',
  styles: []
})
export class ModalComponent implements OnChanges, OnDestroy {
  @Input() title: string = '';
  @Input() size: 'sm' | 'md' | 'lg' | 'xl' = 'md';
  @Input() isOpen: boolean = false;
  @Output() close = new EventEmitter<void>();
  @Output() confirm = new EventEmitter<void>();

  ngOnChanges(changes: SimpleChanges) {
    if (changes['isOpen']) {
      if (this.isOpen) {
        document.body.classList.add('modal-open');
      } else {
        document.body.classList.remove('modal-open');
      }
    }
  }

  ngOnDestroy() {
    document.body.classList.remove('modal-open');
  }

  open() {
    this.isOpen = true;
    document.body.classList.add('modal-open');
  }

  hide() {
    this.isOpen = false;
    document.body.classList.remove('modal-open');
    this.close.emit();
  }
}
