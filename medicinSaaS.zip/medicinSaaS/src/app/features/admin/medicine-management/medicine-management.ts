import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Medicine, Category } from '../../../core/models/medicine.model';
import { DataTableComponent, TableColumn } from '../../../shared/components/data-table/data-table';
import { ModalComponent } from '../../../shared/components/modal/modal';
import { FormInputComponent } from '../../../shared/components/form-input/form-input';
import { Status } from '../../../core/models/common.model';
import { ApiService } from '../../../core/services/api.service';

@Component({
  selector: 'app-medicine-management',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, DataTableComponent, ModalComponent, FormInputComponent],
  templateUrl: './medicine-management.html',
  styles: []
})
export class MedicineManagementComponent {
  private fb = inject(FormBuilder);
  private apiService = inject(ApiService);

  medicines = signal<Medicine[]>([]);
  categories = signal<Category[]>([]);
  
  loading = signal(false);
  isModalOpen = signal(false);
  modalTitle = signal('Add Medicine');

  columns: TableColumn[] = [
    { key: 'name', label: 'Medicine Name', sortable: true },
    { key: 'genericName', label: 'Generic Name' },
    { key: 'categoryName', label: 'Category' },
    { key: 'sku', label: 'SKU' },
    { key: 'price', label: 'Price' },
    { key: 'status', label: 'Status' }
  ];

  medicineForm: FormGroup = this.fb.group({
    id: [''],
    name: ['', [Validators.required]],
    genericName: ['', [Validators.required]],
    categoryId: ['', [Validators.required]],
    sku: ['', [Validators.required]],
    manufacturer: ['', [Validators.required]],
    strength: ['', [Validators.required]],
    unitType: ['Tablet', [Validators.required]],
    price: [0, [Validators.required, Validators.min(0)]],
    costPrice: [0, [Validators.required, Validators.min(0)]],
    minStockLevel: [10, [Validators.required, Validators.min(0)]],
    status: [Status.Active]
  });

  constructor() {
    this.loadData();
  }

  loadData() {
    this.loading.set(true);
    this.apiService.get<Category[]>('/medicineCategories').subscribe((cats: Category[]) => {
      this.categories.set(cats);
      this.loadMedicines();
    });
  }

  loadMedicines() {
    this.apiService.get<Medicine[]>('/medicines').subscribe((meds: Medicine[]) => {
      this.medicines.set(meds);
      this.loading.set(false);
    });
  }

  openAddModal() {
    this.modalTitle.set('Add Medicine');
    this.medicineForm.reset({ unitType: 'Tablet', status: Status.Active, price: 0, costPrice: 0, minStockLevel: 10 });
    this.isModalOpen.set(true);
  }

  editMedicine(medicine: Medicine) {
    this.modalTitle.set('Edit Medicine');
    this.medicineForm.patchValue(medicine);
    this.isModalOpen.set(true);
  }

  saveMedicine() {
    if (this.medicineForm.invalid) {
      this.medicineForm.markAllAsTouched();
      return;
    }

    const medicine = this.medicineForm.value;
    medicine.categoryName = this.getCategoryName(medicine.categoryId);

    if (medicine.id) {
      this.apiService.put<Medicine>(`/medicines/${medicine.id}`, medicine).subscribe((_: Medicine) => {
        this.loadMedicines();
        this.isModalOpen.set(false);
      });
    } else {
      delete medicine.id;
      this.apiService.post<Medicine>('/medicines', medicine).subscribe((_: Medicine) => {
        this.loadMedicines();
        this.isModalOpen.set(false);
      });
    }
  }

  getCategoryName(id: string) {
    return this.categories().find(c => c.id === id)?.name || '';
  }

  deleteMedicine(id: string) {
    if (confirm('Are you sure you want to delete this medicine?')) {
      this.apiService.delete(`/medicines/${id}`).subscribe(() => {
        this.loadMedicines();
      });
    }
  }
}
