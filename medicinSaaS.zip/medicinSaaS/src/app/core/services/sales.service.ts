import { Injectable, inject } from '@angular/core';
import { ApiService } from './api.service';
import { SaleOrder } from '../models/order.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SalesService {
  private api = inject(ApiService);

  getSaleOrders(params: any = {}): Observable<SaleOrder[]> {
    return this.api.get<SaleOrder[]>('/saleOrders', params);
  }

  getSaleOrderById(id: string): Observable<SaleOrder> {
    return this.api.get<SaleOrder>(`/saleOrders/${id}`);
  }

  createSaleOrder(order: Partial<SaleOrder>): Observable<SaleOrder> {
    return this.api.post<SaleOrder>('/saleOrders', order);
  }

  getDailySummaries(): Observable<any[]> {
    return this.api.get<any[]>('/dailyFinancialSummaries');
  }

  getRecentTransactions(branchId?: string): Observable<SaleOrder[]> {
    const params = branchId ? { branchId, _limit: 5, _sort: 'orderDate', _order: 'desc' } : { _limit: 5, _sort: 'orderDate', _order: 'desc' };
    return this.api.get<SaleOrder[]>('/saleOrders', params);
  }
}
