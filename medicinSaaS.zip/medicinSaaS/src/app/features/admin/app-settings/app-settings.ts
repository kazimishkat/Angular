import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-app-settings',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './app-settings.html'
})
export class AppSettingsComponent {}
