import { Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Medicine } from '../../../core/models/medicine.model';
import { SaleOrder, OrderItem } from '../../../core/models/order.model';
import { AuthService } from '../../../core/services/auth.service';
import { BranchService } from '../../../core/services/branch.service';
import { MedicineService } from '../../../core/services/medicine.service';
import { SalesService } from '../../../core/services/sales.service';

@Component({
  selector: 'app-pos',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './pos.html',
  styles: [`
    .cart-container { height: calc(100vh - 400px); overflow-y: auto; }
    .product-grid { height: calc(100vh - 200px); overflow-y: auto; }
    .product-card:hover { border-color: #0d6efd !important; cursor: pointer; }
  `]
})
export class PosComponent {
  private fb = inject(FormBuilder);
  private authService = inject(AuthService);
  private branchService = inject(BranchService);
  private medicineService = inject(MedicineService);
  private salesService = inject(SalesService);

  user = this.authService.currentUser;
  branchName = signal('Loading...');

  cartItems = signal<OrderItem[]>([]);
  searchQuery = signal('');
  
  availableMedicines = signal<Medicine[]>([]);

  ngOnInit() {
    const branchId = this.user()?.branchId;
    if (branchId) {
      this.branchService.getBranchById(branchId).subscribe(b => {
        if (b) this.branchName.set(b.name);
      });
    }
    this.loadMedicines();
  }

  loadMedicines() {
    this.medicineService.getMedicines().subscribe(meds => {
      this.availableMedicines.set(meds);
    });
  }

  filteredMedicines = computed(() => {
    const query = this.searchQuery().toLowerCase();
    return this.availableMedicines().filter(m => 
      m.name.toLowerCase().includes(query) || 
      m.genericName.toLowerCase().includes(query) ||
      m.sku.toLowerCase().includes(query)
    );
  });

  subTotal = computed(() => this.cartItems().reduce((acc, item) => acc + item.totalPrice, 0));
  tax = computed(() => this.subTotal() * 0.1); // 10% Tax
  totalAmount = computed(() => this.subTotal() + this.tax());

  addToCart(medicine: Medicine) {
    this.cartItems.update(items => {
      const existing = items.find(i => i.medicineId === medicine.id);
      if (existing) {
        return items.map(i => i.medicineId === medicine.id 
          ? { ...i, quantity: i.quantity + 1, totalPrice: (i.quantity + 1) * i.unitPrice } 
          : i);
      }
      return [...items, {
        id: Math.random().toString(),
        orderId: '',
        medicineId: medicine.id,
        medicineName: medicine.name,
        quantity: 1,
        unitPrice: medicine.price,
        discount: 0,
        totalPrice: medicine.price
      }];
    });
  }

  updateQuantity(medicineId: string, delta: number) {
    this.cartItems.update(items => items.map(i => {
      if (i.medicineId === medicineId) {
        const newQty = Math.max(1, i.quantity + delta);
        return { ...i, quantity: newQty, totalPrice: newQty * i.unitPrice };
      }
      return i;
    }));
  }

  removeFromCart(medicineId: string) {
    this.cartItems.update(items => items.filter(i => i.medicineId !== medicineId));
  }

  checkout() {
    if (this.cartItems().length === 0) return;
    const newOrder: Partial<SaleOrder> = {
      orderNumber: `ORD-${Math.floor(1000 + Math.random() * 9000)}`,
      branchId: this.user()?.branchId || 'b1',
      staffId: this.user()?.id || '3',
      orderDate: new Date().toISOString(),
      totalAmount: this.totalAmount(),
      status: 'Completed',
      items: this.cartItems()
    } as any;

    this.salesService.createSaleOrder(newOrder).subscribe({
      next: (res) => {
        alert(`Payment of $${this.totalAmount().toFixed(2)} completed successfully!`);
        this.cartItems.set([]);
      },
      error: (err) => {
        console.error('Checkout failed', err);
        alert('Checkout failed, please try again.');
      }
    });
  }
}
