import { Injectable, inject } from '@angular/core';
import { ApiService } from './api.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  private api = inject(ApiService);

  getEmployees(params: any = {}): Observable<any[]> {
    return this.api.get<any[]>('/employees', params);
  }

  getEmployeeById(id: string): Observable<any> {
    return this.api.get<any>(`/employees/${id}`);
  }

  createEmployee(employee: any): Observable<any> {
    return this.api.post<any>('/employees', employee);
  }

  updateEmployee(id: string, employee: any): Observable<any> {
    return this.api.put<any>(`/employees/${id}`, employee);
  }

  deleteEmployee(id: string): Observable<void> {
    return this.api.delete<void>(`/employees/${id}`);
  }

  getAttendance(params: any = {}): Observable<any[]> {
    return this.api.get<any[]>('/attendanceRecords', params);
  }
}
