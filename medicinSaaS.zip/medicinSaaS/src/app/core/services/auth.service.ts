import { Injectable, signal, computed } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, tap, of, throwError, map } from 'rxjs';
import { User, UserRole } from '../models/user.model';
import { ApiResponse } from '../models/common.model';
import { ApiService } from './api.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private currentUserSignal = signal<User | null>(null);
  currentUser = computed(() => this.currentUserSignal());
  isAuthenticated = computed(() => !!this.currentUserSignal());

  constructor(private http: HttpClient, private router: Router, private api: ApiService) {
    this.loadUserFromStorage();
  }

  login(credentials: any): Observable<any> {
    return this.api.get<User[]>('/users').pipe(
      map(allUsers => {
        const identifier = credentials.email.toLowerCase();
        const user = allUsers.find(u => 
          (u.email && u.email.toLowerCase() === identifier) ||
          (u.username && u.username.toLowerCase() === identifier) ||
          (u.role && u.role.toLowerCase() === identifier)
        );
        
        if (user) {
          if ((user as any).password === credentials.password) {
            return { user, token: 'mock-jwt-token-' + user.id };
          } else {
            throw new Error('Invalid credentials');
          }
        }
        throw new Error('User not found');
      }),
      tap(res => {
        this.setSession(res.user, res.token);
      })
    );
  }

  register(userData: any): Observable<any> {
    // Generate an ID
    const newUser = {
      ...userData,
      id: Math.floor(1000 + Math.random() * 9000).toString(),
      status: 'Active'
    };
    return this.api.post<User>('/users', newUser);
  }

  logout(): void {
    this.currentUserSignal.set(null);
    localStorage.removeItem('user');
    localStorage.removeItem('token');
    this.router.navigate(['/']);
  }

  hasRole(role: UserRole): boolean {
    const user = this.currentUser();
    return user?.role === role;
  }

  private setSession(user: User, token: string): void {
    this.currentUserSignal.set(user);
    localStorage.setItem('user', JSON.stringify(user));
    localStorage.setItem('token', token);
  }

  private loadUserFromStorage(): void {
    const userJson = localStorage.getItem('user');
    if (userJson) {
      this.currentUserSignal.set(JSON.parse(userJson));
    }
  }

  getToken(): string | null {
    return localStorage.getItem('token');
  }
}
