import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductRequestService, ProductRequest } from '../../../core/services/product-request.service';
import { MedicineService } from '../../../core/services/medicine.service';
import { AuthService } from '../../../core/services/auth.service';
import { SupplierService } from '../../../core/services/supplier.service';
import { InventoryService } from '../../../core/services/inventory.service';
import { DataTableComponent, TableColumn } from '../../../shared/components/data-table/data-table';
import { Medicine } from '../../../core/models/medicine.model';
import { Status } from '../../../core/models/common.model';

@Component({
  selector: 'app-manager-product-requests',
  standalone: true,
  imports: [CommonModule, DataTableComponent],
  templateUrl: './product-requests.html'
})
export class ManagerProductRequestsComponent implements OnInit {
  private requestService = inject(ProductRequestService);
  private medicineService = inject(MedicineService);
  private authService = inject(AuthService);
  private supplierService = inject(SupplierService);
  private inventoryService = inject(InventoryService);

  requests = signal<ProductRequest[]>([]);
  loading = signal(false);
  
  columns: TableColumn[] = [
    { key: 'requestDate', label: 'Date', sortable: true },
    { key: 'staffId', label: 'Staff ID' },
    { key: 'medicineName', label: 'Product' },
    { key: 'quantity', label: 'Quantity' },
    { key: 'status', label: 'Status' }
  ];

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    this.loading.set(true);
    const user = this.authService.currentUser();
    
    this.medicineService.getMedicines().subscribe(meds => {
      // If Admin, see all. If Manager, see branch specific
      const queryParams = user?.role === 'Manager' ? { branchId: user.branchId } : {};
      
      this.requestService.getRequests(queryParams).subscribe(reqs => {
        const enriched = reqs.map(r => ({
          ...r,
          medicineName: r.medicineName || meds.find(m => m.id === r.medicineId)?.name || 'Unknown'
        }));
        this.requests.set(enriched);
        this.loading.set(false);
      });
    });
  }

  acceptRequest(request: ProductRequest) {
    if (confirm('Are you sure you want to accept and proceed with this request?')) {
      this.requestService.updateRequest(request.id!, { status: 'Accepted' }).subscribe(() => {
        // Automatically create Purchase Order and Update Inventory
        this.medicineService.getMedicines().subscribe(meds => {
          let med = meds.find(m => m.id === request.medicineId);
          
          const processOrder = (processedMed: Medicine) => {
             if (request.supplierId) {
                 const newPo = {
                    poNumber: 'PO-' + Math.floor(1000 + Math.random() * 9000),
                    supplierId: request.supplierId,
                    branchId: request.branchId,
                    orderDate: new Date().toISOString().split('T')[0],
                    expectedDeliveryDate: new Date().toISOString().split('T')[0],
                    status: 'Completed',
                    totalAmount: processedMed.costPrice * request.quantity,
                    items: [{ medicineId: processedMed.id, quantity: request.quantity, unitPrice: processedMed.costPrice, totalPrice: processedMed.costPrice * request.quantity }]
                 };
                 
                 this.supplierService.createPurchaseOrder(newPo).subscribe(() => {
                    this.inventoryService.getInventoryByBranch(request.branchId).subscribe((invs: any[]) => {
                       const inv = invs.find(i => i.medicineId === processedMed.id);
                       if (inv) {
                          this.inventoryService.updateStock(inv.id, inv.totalQuantity + request.quantity).subscribe(() => {
                             this.loadData();
                          });
                       } else {
                          this.inventoryService.createInventory({
                             medicineId: processedMed.id,
                             branchId: request.branchId,
                             totalQuantity: request.quantity,
                             expiryDate: new Date(new Date().setFullYear(new Date().getFullYear() + 1)).toISOString().split('T')[0],
                             supplierId: request.supplierId
                          }).subscribe(() => {
                             this.loadData();
                          });
                       }
                    });
                 });
             } else {
               this.loadData();
             }
          };

          if (!med && request.medicineName) {
            // Create a new medicine entry dynamically
            const newMed: Medicine = {
              id: 'm' + Math.floor(1000 + Math.random() * 9000),
              name: request.medicineName,
              genericName: 'Unknown',
              categoryId: '1',
              sku: 'MED-' + Math.floor(1000 + Math.random() * 9000),
              manufacturer: 'Unknown',
              strength: 'N/A',
              unitType: 'Unit',
              price: 10,
              costPrice: 5,
              minStockLevel: 10,
              status: Status.Active
            };
            this.medicineService.createMedicine(newMed).subscribe(createdMed => {
               // Update request with the new medicine ID
               this.requestService.updateRequest(request.id!, { medicineId: createdMed.id }).subscribe();
               processOrder(createdMed);
            });
          } else if (med) {
             processOrder(med);
          } else {
             this.loadData();
          }
        });
      });
    }
  }

  rejectRequest(request: ProductRequest) {
    if (confirm('Are you sure you want to reject this request?')) {
      this.requestService.updateRequest(request.id!, { status: 'Rejected' }).subscribe(() => {
        this.loadData();
      });
    }
  }
}
