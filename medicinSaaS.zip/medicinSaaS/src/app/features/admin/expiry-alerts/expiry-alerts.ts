import { Component, inject, signal, OnInit, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InventoryService } from '../../../core/services/inventory.service';
import { MedicineService } from '../../../core/services/medicine.service';
import { DataTableComponent, TableColumn } from '../../../shared/components/data-table/data-table';

@Component({
  selector: 'app-expiry-alerts',
  standalone: true,
  imports: [CommonModule, DataTableComponent],
  templateUrl: './expiry-alerts.html',
  styles: []
})
export class ExpiryAlertsComponent implements OnInit {
  private inventoryService = inject(InventoryService);
  private medicineService = inject(MedicineService);

  alerts = signal<any[]>([]);
  loading = signal(false);

  columns: TableColumn[] = [
    { key: 'medicineName', label: 'Medicine' },
    { key: 'batchNumber', label: 'Batch #' },
    { key: 'expiryDate', label: 'Expiry Date', sortable: true },
    { key: 'daysRemaining', label: 'Days Remaining', sortable: true },
    { key: 'status', label: 'Priority' }
  ];

  ngOnInit() {
    this.loadAlerts();
  }

  loadAlerts() {
    this.loading.set(true);
    // Mocking expiry data based on medicines and batches
    this.medicineService.getMedicines().subscribe(meds => {
      const mockAlerts = meds.map((m, index) => {
        const expiryDate = new Date();
        expiryDate.setDate(expiryDate.getDate() + (index * 15) + 5);
        const daysRemaining = Math.ceil((expiryDate.getTime() - new Date().getTime()) / (1000 * 3600 * 24));
        
        return {
          id: m.id,
          medicineName: m.name,
          batchNumber: 'B-' + Math.floor(1000 + Math.random() * 9000),
          expiryDate: expiryDate.toISOString().split('T')[0],
          daysRemaining: daysRemaining,
          status: daysRemaining < 10 ? 'High' : (daysRemaining < 30 ? 'Medium' : 'Low')
        };
      });
      this.alerts.set(mockAlerts);
      this.loading.set(false);
    });
  }

  getPriorityClass(status: string) {
    switch (status) {
      case 'High': return 'bg-danger-subtle text-danger';
      case 'Medium': return 'bg-warning-subtle text-warning';
      default: return 'bg-info-subtle text-info';
    }
  }
}
