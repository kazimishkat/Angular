import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NotificationService } from '../../../core/services/notification.service';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-notification-dropdown',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './notification-dropdown.html',
  styles: [`
    .notification-list { max-height: 400px; overflow-y: auto; width: 320px; }
    .notification-item { border-bottom: 1px solid #f0f0f0; transition: background 0.2s; }
    .notification-item:hover { background: #f8f9fa; }
    .notification-item.unread { border-left: 3px solid #0d6efd; background: #f0f7ff; }
  `]
})
export class NotificationDropdownComponent implements OnInit {
  notificationService = inject(NotificationService);
  private authService = inject(AuthService);

  ngOnInit() {
    const user = this.authService.currentUser();
    if (user) {
      this.notificationService.loadNotifications(user.id);
    }
  }

  markRead(id: string) {
    this.notificationService.markAsRead(id);
  }

  markAllRead() {
    const user = this.authService.currentUser();
    if (user) this.notificationService.markAllAsRead(user.id);
  }
}
