import { Component, inject, signal, OnInit, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../../core/services/api.service';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-pharmacist-portal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './pharmacist-portal.html',
  styles: [`
    .prescription-img { 
      max-height: 400px; 
      object-fit: contain; 
      border-radius: 8px; 
      transition: transform 0.2s ease;
    }
    .allergy-pulse {
      animation: pulse 2s infinite;
    }
    @keyframes pulse {
      0% { opacity: 1; }
      50% { opacity: 0.6; }
      100% { opacity: 1; }
    }
  `]
})
export class PharmacistPortalComponent implements OnInit {
  private api = inject(ApiService);
  private authService = inject(AuthService);

  user = this.authService.currentUser;
  activeTab = signal<'prescriptions' | 'medical-notes' | 'alternatives' | 'returns'>('prescriptions');

  // Database Signals
  prescriptions = signal<any[]>([]);
  customers = signal<any[]>([]);
  medicines = signal<any[]>([]);
  returnRecords = signal<any[]>([]);
  damages = signal<any[]>([]);
  batches = signal<any[]>([]);
  saleOrders = signal<any[]>([]);

  // Selection & UI controls
  selectedCustomerId = signal<string>('');
  alternativeSearch = signal<string>('');
  
  // Prescription verification workspace signals
  selectedPrescriptionId = signal<string | null>(null);
  zoomLevel = signal<number>(100);
  rotationAngle = signal<number>(0);
  rejectionReason = signal<string>('');
  showRejectionModal = signal<boolean>(false);
  
  // History Filters
  rxHistorySearch = signal<string>('');
  rxHistoryStatusFilter = signal<'All' | 'Approved' | 'Rejected'>('All');

  // Toast notification state
  toast = signal<{ message: string, type: 'success' | 'danger' | 'info' } | null>(null);

  // Selected customer computed
  selectedCustomer = computed(() => {
    return this.customers().find(c => c.id === this.selectedCustomerId());
  });

  // Selected prescription computed
  selectedPrescription = computed(() => {
    const id = this.selectedPrescriptionId();
    if (!id) return null;
    const rx = this.prescriptions().find(p => p.id === id);
    if (!rx) return null;
    
    // Find customer details for this prescription
    const customer = this.customers().find(c => c.id === rx.customerId || c.userId === rx.customerId);
    return {
      ...rx,
      customerProfile: customer || null
    };
  });

  // Pending prescriptions computed
  pendingPrescriptions = computed(() => {
    return this.prescriptions().filter(p => p.status === 'Pending');
  });

  // Filtered prescription history computed
  filteredPrescriptionHistory = computed(() => {
    const search = this.rxHistorySearch().toLowerCase().trim();
    const status = this.rxHistoryStatusFilter();
    
    return this.prescriptions().filter(p => {
      if (p.status === 'Pending') return false; // History only shows verified ones
      
      const matchesStatus = status === 'All' || p.status === status;
      const matchesSearch = !search || 
        p.customerName.toLowerCase().includes(search) || 
        (p.doctorName && p.doctorName.toLowerCase().includes(search)) ||
        p.medicineName.toLowerCase().includes(search);
        
      return matchesStatus && matchesSearch;
    });
  });

  // Alternatives computed list
  alternativesList = computed(() => {
    const query = this.alternativeSearch().toLowerCase().trim();
    if (!query) return [];
    
    const match = this.medicines().find(m => 
      m.name.toLowerCase().includes(query) || 
      m.genericName.toLowerCase().includes(query)
    );
    if (!match) return [];

    return this.medicines()
      .filter(m => m.id !== match.id && (
        m.genericName.toLowerCase() === match.genericName.toLowerCase() ||
        m.categoryId === match.categoryId
      ))
      .map(m => ({
        ...m,
        matchType: m.genericName.toLowerCase() === match.genericName.toLowerCase() 
          ? 'Generic Substitute' 
          : 'Alternative Brand (Same Composition)'
      }));
  });

  // Form Models
  returnForm = { 
    customerId: '', 
    medicineId: '', 
    quantity: 1, 
    refundAmount: 0, 
    reason: 'Wrong medication', 
    restock: true 
  };
  
  damageForm = { 
    medicineId: '', 
    batchId: '', 
    quantity: 1, 
    reason: 'Expired' 
  };

  ngOnInit() {
    this.loadPortalData();
  }

  showToast(message: string, type: 'success' | 'danger' | 'info' = 'success') {
    this.toast.set({ message, type });
    setTimeout(() => {
      this.toast.set(null);
    }, 4000);
  }

  loadPortalData() {
    this.api.get<any[]>('/prescriptions').subscribe({
      next: data => {
        this.prescriptions.set(data);
        // Default select first pending prescription if any
        const pending = data.filter(p => p.status === 'Pending');
        if (pending.length > 0 && !this.selectedPrescriptionId()) {
          this.selectedPrescriptionId.set(pending[0].id);
        }
      }
    });

    this.api.get<any[]>('/customers').subscribe(data => {
      this.api.get<any[]>('/users').subscribe(users => {
        const enriched = data.map(c => {
          const u = users.find(usr => usr.id === c.userId);
          return {
            ...c,
            fullName: u ? `${u.firstName} ${u.lastName}` : `Customer #${c.id}`
          };
        });
        this.customers.set(enriched);
        if (enriched.length > 0 && !this.selectedCustomerId()) {
          this.selectedCustomerId.set(enriched[0].id);
        }
      });
    });

    this.api.get<any[]>('/medicines').subscribe(data => this.medicines.set(data));
    this.api.get<any[]>('/returnRecords').subscribe(data => this.returnRecords.set(data));
    this.api.get<any[]>('/damages').subscribe(data => this.damages.set(data));
    this.api.get<any[]>('/batches').subscribe(data => this.batches.set(data));
    this.api.get<any[]>('/saleOrders').subscribe(data => this.saleOrders.set(data));
  }

  // Prescription Zoom/Rotation Simulator controls
  zoomIn() {
    this.zoomLevel.update(z => Math.min(z + 20, 200));
  }

  zoomOut() {
    this.zoomLevel.update(z => Math.max(z - 20, 60));
  }

  rotate() {
    this.rotationAngle.update(r => (r + 90) % 360);
  }

  resetImage() {
    this.zoomLevel.set(100);
    this.rotationAngle.set(0);
  }

  verifyPrescription(id: string, status: 'Approved' | 'Rejected', reason: string = '') {
    const rx = this.prescriptions().find(p => p.id === id);
    if (!rx) return;
    
    const updated = { 
      ...rx, 
      status, 
      verificationNotes: reason || (status === 'Approved' ? 'Verified & approved by Pharmacist' : 'Rejected'),
      verifiedBy: this.user()?.username || 'Staff Pharmacist',
      verificationDate: new Date().toISOString().split('T')[0]
    };

    this.api.put(`/prescriptions/${id}`, updated).subscribe({
      next: () => {
        this.prescriptions.update(list => list.map(p => p.id === id ? updated : p));
        this.showToast(`Prescription ${status.toLowerCase()} successfully.`, status === 'Approved' ? 'success' : 'danger');
        
        // Clear selection or select next pending
        const remainingPending = this.pendingPrescriptions().filter(p => p.id !== id);
        if (remainingPending.length > 0) {
          this.selectedPrescriptionId.set(remainingPending[0].id);
        } else {
          this.selectedPrescriptionId.set(null);
        }
        this.rejectionReason.set('');
        this.showRejectionModal.set(false);
      },
      error: () => this.showToast('Failed to update prescription status.', 'danger')
    });
  }

  triggerReject() {
    if (!this.rejectionReason().trim()) {
      this.showToast('Please select or specify a rejection reason.', 'danger');
      return;
    }
    const id = this.selectedPrescriptionId();
    if (id) {
      this.verifyPrescription(id, 'Rejected', this.rejectionReason());
    }
  }

  // Returns logic helpers
  onReturnMedicineChange() {
    const med = this.medicines().find(m => m.id === this.returnForm.medicineId);
    if (med) {
      this.returnForm.refundAmount = Number((med.price * this.returnForm.quantity).toFixed(2));
    }
  }

  onReturnQuantityChange() {
    this.onReturnMedicineChange();
  }

  submitReturn() {
    if (!this.returnForm.customerId || !this.returnForm.medicineId || this.returnForm.quantity <= 0) {
      this.showToast('Please fill all returns fields correctly.', 'danger');
      return;
    }
    const customer = this.customers().find(c => c.id === this.returnForm.customerId);
    const medicine = this.medicines().find(m => m.id === this.returnForm.medicineId);
    
    if (!customer || !medicine) return;

    const newReturn = {
      customerId: this.returnForm.customerId,
      customerName: customer.fullName,
      medicineName: medicine.name,
      medicineId: this.returnForm.medicineId,
      quantity: this.returnForm.quantity,
      refundAmount: this.returnForm.refundAmount,
      reason: this.returnForm.reason,
      restocked: this.returnForm.restock,
      status: 'Processed',
      date: new Date().toISOString().split('T')[0]
    };

    this.api.post<any>('/returnRecords', newReturn).subscribe({
      next: saved => {
        this.returnRecords.update(list => [saved, ...list]);
        this.showToast('Medicine return processed & refund recorded.', 'success');
        
        // If restock is selected, update inventory quantity (simulate it)
        if (this.returnForm.restock) {
          this.api.get<any[]>('/inventories').subscribe(invList => {
            const entry = invList.find(i => i.medicineId === this.returnForm.medicineId && i.branchId === (this.user()?.branchId || 'b1'));
            if (entry) {
              this.api.put(`/inventories/${entry.id}`, {
                ...entry,
                totalQuantity: entry.totalQuantity + this.returnForm.quantity
              }).subscribe();
            }
          });
        }

        // Reset Form
        this.returnForm = { 
          customerId: this.customers()[0]?.id || '', 
          medicineId: this.medicines()[0]?.id || '', 
          quantity: 1, 
          refundAmount: 0, 
          reason: 'Wrong medication', 
          restock: true 
        };
        this.onReturnMedicineChange();
      },
      error: () => this.showToast('Failed to process return record.', 'danger')
    });
  }

  // Damages logic helpers
  getBatchesForSelectedDamageMedicine() {
    if (!this.damageForm.medicineId) return [];
    return this.batches().filter(b => b.medicineId === this.damageForm.medicineId && b.branchId === (this.user()?.branchId || 'b1'));
  }

  submitDamage() {
    if (!this.damageForm.medicineId || this.damageForm.quantity <= 0) {
      this.showToast('Please select a medicine and valid quantity.', 'danger');
      return;
    }

    const medicine = this.medicines().find(m => m.id === this.damageForm.medicineId);
    if (!medicine) return;

    const selectedBatch = this.batches().find(b => b.id === this.damageForm.batchId);
    
    const newDamage = {
      medicineName: medicine.name,
      medicineId: this.damageForm.medicineId,
      batchId: this.damageForm.batchId || 'N/A',
      batchNumber: selectedBatch ? selectedBatch.batchNumber : 'N/A',
      quantity: this.damageForm.quantity,
      reason: this.damageForm.reason,
      reportedBy: this.user()?.username || 'Staff Pharmacist',
      date: new Date().toISOString().split('T')[0],
      branchId: this.user()?.branchId || 'b1'
    };

    this.api.post<any>('/damages', newDamage).subscribe({
      next: saved => {
        this.damages.update(list => [saved, ...list]);
        this.showToast('Damaged/Expired stock report registered.', 'success');
        
        // Deduct from inventory/batch (simulation)
        this.api.get<any[]>('/inventories').subscribe(invList => {
          const entry = invList.find(i => i.medicineId === this.damageForm.medicineId && i.branchId === (this.user()?.branchId || 'b1'));
          if (entry) {
            this.api.put(`/inventories/${entry.id}`, {
              ...entry,
              totalQuantity: Math.max(0, entry.totalQuantity - this.damageForm.quantity)
            }).subscribe();
          }
        });

        // Reset Form
        this.damageForm = { medicineId: '', batchId: '', quantity: 1, reason: 'Expired' };
      },
      error: () => this.showToast('Failed to register damage report.', 'danger')
    });
  }
}
