import { Component, Input, Output, EventEmitter, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-confirm-modal',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './confirm-modal.html',
  styles: []
})
export class ConfirmModalComponent {
  @Input() title: string = 'Confirm Action';
  @Input() message: string = 'Are you sure you want to proceed?';
  @Input() confirmText: string = 'Confirm';
  @Input() cancelText: string = 'Cancel';
  @Input() confirmColor: string = 'danger'; // primary, danger, warning

  @Output() confirmed = new EventEmitter<void>();
  @Output() cancelled = new EventEmitter<void>();

  isOpen = signal(false);

  show() {
    this.isOpen.set(true);
  }

  hide() {
    this.isOpen.set(false);
  }

  onConfirm() {
    this.confirmed.emit();
    this.hide();
  }

  onCancel() {
    this.cancelled.emit();
    this.hide();
  }
}
